import urllib.parse
from typing import Optional, IO

import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy import select
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import Session
from sqlalchemy.orm import mapped_column
from werkzeug.datastructures import FileStorage

engine = create_engine("sqlite:///../resources/foo.db", echo=False)


class Base(DeclarativeBase):
    pass


class TaskOverview(Base):
    __tablename__ = "overviewpages"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    type: Mapped[str]
    request_method: Mapped[str]
    url: Mapped[str]
    retrieval_endpoint: Mapped[Optional[str]]  # Describes the API endpoint if overview page performs XHR calls
    selector: Mapped[Optional[str]] = mapped_column(default="")  # Point retriever to the correct part of of the resp.
    body: Mapped[Optional[str]] = mapped_column(default="")  # If request requires special retrieval body
    header: Mapped[Optional[str]] = mapped_column(default="")  # If request requires special retrieval headers
    mapping: Mapped[Optional[str]] = mapped_column(default="")  # Overview table column mapping
    contentmapping: Mapped[Optional[str]] = mapped_column(default="")  # Site segmentation with content types
    ignorereferences: Mapped[Optional[str]] = mapped_column(default="")  # Links that should be ignored (no refs)
    interval: Mapped[Optional[str]] = mapped_column(default="")  # Minutes between retrieval attempts
    statusmessage: Mapped[Optional[str]] = mapped_column(default="")  # Store retrieval errors here
    lastretrievalattempt: Mapped[Optional[str]] = mapped_column(default="")  # Timestamp of last retrieval attempt
    lastretrieved: Mapped[Optional[str]] = mapped_column(default="")  # Timestamp of last successful retrieval

    def __repr__(self):
        return f"OverviewPage(id={self.id}, type={self.type}, url={self.url})"


class TaskDetail(Base):
    __tablename__ = "detailpages"

    # id: Mapped[int] = mapped_column(primary_key=True)
    domain: Mapped[str]
    url: Mapped[Optional[str]] = mapped_column(primary_key=True)
    firstseen: Mapped[Optional[str]]
    lastretrieved: Mapped[Optional[str]]
    title: Mapped[Optional[str]]
    identifier: Mapped[Optional[str]] = mapped_column(primary_key=True)
    products: Mapped[Optional[str]]
    vendor: Mapped[Optional[str]]
    published: Mapped[Optional[str]]
    updated: Mapped[Optional[str]]
    cve: Mapped[Optional[str]]
    score: Mapped[Optional[str]]
    severity: Mapped[Optional[str]]
    content: Mapped[Optional[str]]
    summary: Mapped[Optional[str]]
    type: Mapped[Optional[str]]
    retrievalserverts: Mapped[Optional[str]]
    retrievaletag: Mapped[Optional[str]]
    properties: Mapped[Optional[str]]


class TaskOverviewDisplayWrapper:
    def __init__(self, task: TaskOverview):
        self.task = task
        try:
            self.provider_name = urllib.parse.urlparse(self.task.url).netloc
        except Exception:
            self.provider_name = "Default Value"
        if not task.interval:
            self.interval = 30  # Default interval
        self.lastretshort = str(task.lastretrievalattempt)[0:19]

    def __getattr__(self, attr):
        if hasattr(self.task, attr):
            # Return truncated attribute of wrapped class
            return str(getattr(self.task, attr))[:120]
        elif hasattr(self, attr):
            # Return wrapper attribute
            return getattr(self, attr)
        else:
            raise AttributeError


def query_overview_pages():
    with Session(engine) as session:
        stmt = select(TaskOverview)  # .where(OverviewPage.type == "ajax")
        pages = [ovp for ovp in session.scalars(stmt)]
    return pages


def process_import(engine, file: IO | FileStorage) -> int:
    """
    Take a filelike object (or whatever pandas can read csv from), parse it, and write TaskOverview objs to the DB."""
    df = pd.read_csv(file)
    list_of_dicts = df.to_dict('records')
    processed_lst = []
    for elem in list_of_dicts:
        # Remove the following dict items:
        # Value is nan, Key is id (headers)
        processed_lst.append({k: v for k, v in elem.items() if (not pd.isna(v) and not k == "id")})
    with Session(engine) as session:
        for enum, record in enumerate(processed_lst):
            task = TaskOverview(**record)
            session.add(task)
        session.commit()
    return len(processed_lst)


if __name__ == '__main__':
    Base.metadata.create_all(engine)
    # fill_db()
    # print(query_overview_pages())
    # fill_db_from_csv()
