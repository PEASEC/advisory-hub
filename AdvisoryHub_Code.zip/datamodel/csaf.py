from sqlalchemy import create_engine, ForeignKey, ForeignKeyConstraint
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import relationship, Mapped, mapped_column
from typing import List, Optional

Base = declarative_base()


class Document(Base):
    __tablename__ = "document"

    provider: Mapped[str] = mapped_column(primary_key=True)
    identifier: Mapped[str] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column()
    filepath: Mapped[str] = mapped_column()
    url: Mapped[Optional[str]] = mapped_column(default="")
    published: Mapped[Optional[str]] = mapped_column(default="")
    updated: Mapped[Optional[str]] = mapped_column(default="")
    downloaded: Mapped[Optional[str]] = mapped_column(default="")
    severity: Mapped[Optional[str]] = mapped_column(default="")
    cvss: Mapped[Optional[str]] = mapped_column(default="")
    products: Mapped[Optional[str]] = mapped_column(default="")
    vulnerabilities: Mapped[List["Vulnerability"]] = relationship(
        "Vulnerability",
        secondary="documentvulnerability",
        back_populates="documents",
    )
    vendors: Mapped[List["Vendor"]] = relationship(
        "Vendor",
        secondary="documentvendor",
        back_populates="documents",
    )


class Vulnerability(Base):
    __tablename__ = "vulnerability"

    identifier: Mapped[str] = mapped_column(primary_key=True)

    documents: Mapped[List["Document"]] = relationship(
        "Document",
        secondary="documentvulnerability",
        back_populates="vulnerabilities",
    )


class Vendor(Base):
    __tablename__ = "vendor"

    name: Mapped[str] = mapped_column(primary_key=True)

    documents: Mapped[List["Document"]] = relationship(
        "Document",
        secondary="documentvendor",
        back_populates="vendors",
    )


class DocumentVulnerability(Base):
    __tablename__ = "documentvulnerability"

    vulnerability_identifier: Mapped[str] = mapped_column(ForeignKey(Vulnerability.identifier), primary_key=True)
    document_provider: Mapped[str] = mapped_column(primary_key=True)
    document_identifier: Mapped[str] = mapped_column(primary_key=True)

    __table_args__ = (
        ForeignKeyConstraint(
            ["document_provider", "document_identifier"],
            ["document.provider", "document.identifier"],
        ),
    )


class DocumentVendor(Base):
    __tablename__ = "documentvendor"

    vendor_name: Mapped[str] = mapped_column(ForeignKey(Vendor.name), primary_key=True)
    document_provider: Mapped[str] = mapped_column(primary_key=True)
    document_identifier: Mapped[str] = mapped_column(primary_key=True)

    __table_args__ = (
        ForeignKeyConstraint(
            ["document_provider", "document_identifier"],
            ["document.provider", "document.identifier"],
        ),
    )


class LastCheck(Base):
    __tablename__ = "lastcheck"

    date: Mapped[str] = mapped_column(primary_key=True, nullable=True)


if __name__ == '__main__':
    engine = create_engine("sqlite:///resources/csaf.db", echo=False)
    Base.metadata.create_all(engine)
