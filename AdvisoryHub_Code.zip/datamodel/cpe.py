from typing import List

from sqlalchemy import ForeignKey
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class Vendor(Base):
    __tablename__ = "vendor"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name: Mapped[str]
    # words: Mapped[int]
    products: Mapped[List["Product"]] = relationship(back_populates="vendor", cascade="all, delete-orphan")


class Product(Base):
    __tablename__ = "product"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str]
    # words: Mapped[int]
    vendor_id: Mapped[int] = mapped_column(ForeignKey("vendor.id"))
    vendor: Mapped["Vendor"] = relationship(back_populates="products")
