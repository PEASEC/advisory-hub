import logging
import threading
import time
from datetime import datetime, timezone, timedelta

import dateutil.parser
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from batchjobs.batchbase import BatchBase
from datamodel.task import TaskOverview
from monitoring.connectors.base import BasicRetriever
from monitoring.connectors.factory import get_retriever
from monitoring.retrieverlogging import setup_logger


class MonitoringThread(BatchBase):
    MAXTHREADCOUNT = 4

    def __init__(self, interval: timedelta, engine, logger: logging.Logger):
        super(MonitoringThread, self).__init__(interval)
        self.engine = engine
        self.session = Session(engine)
        self.logger = logger

    def action(self):
        """Monitor DB and spawn Retrievers if tasks are eligible for retrieval."""
        # Get all tasks from DB and retrieve those that eligible for retrieval
        for task in self.session.query(TaskOverview):
            while self.get_retriever_count() > self.MAXTHREADCOUNT:
                time.sleep(15)  # Check every 15 seconds if receiver slot is available
                print("Waiting for free retriever slot.")

            if self.recrawl_eligible(task):  # Check if task needs new retrieval
                retriever = get_retriever(task, self.logger, self.engine)
                retriever.start()

                task.lastretrievalattempt = str(datetime.now(timezone.utc))  # Store timestamp in DB
                self.session.commit()

    @staticmethod
    def get_retriever_count():
        """Return number of currently running threads that inherit from BasicRetriever"""
        # There is probably a better way to do this while still ignoring MonitoringThread, DbThread, _MainThread
        thread_classes = [type(t).__name__ for t in threading.enumerate() if isinstance(t, BasicRetriever)]
        return len(thread_classes)

    @staticmethod
    def recrawl_eligible(task) -> bool:
        """Check if task should already be retrieved."""

        # Set interval to value stored in DB, set it to 30 minutes if no value is set
        interval = int(task.interval) if task.interval != "" and task.interval is not None else 30

        recrawl = False
        if task.lastretrievalattempt == "" or task.lastretrievalattempt is None:
            recrawl = True
        else:
            timestamp_dt = dateutil.parser.parse(task.lastretrievalattempt)
            current_dt = datetime.now(timezone.utc)
            if timestamp_dt + timedelta(minutes=interval) < current_dt:
                recrawl = True
        return recrawl


if __name__ == '__main__':
    logger = setup_logger("OverviewMonitor")

    engine = create_engine("sqlite:///resources/task.db", echo=False)

    m_t = MonitoringThread(timedelta(seconds=10), engine, logger)
    m_t.start()
    while True:
        time.sleep(10)
        thread_names = [t.name for t in threading.enumerate()]
        thread_classes = [type(t).__name__ for t in threading.enumerate()]
        print(thread_names)
        print(thread_classes)
