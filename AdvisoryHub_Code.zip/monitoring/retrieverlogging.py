import logging


def setup_logger(name: str):
    """Custom logger class that sends logs to both file and stdout"""
    logger = logging.getLogger(name)
    file_name = "../test_log.txt"

    # If this is set to INFO, no debug messages are sent to the handlers
    logger.setLevel(logging.DEBUG)

    log_format = logging.Formatter('%(asctime)s,%(msecs)d,%(thread)d, %(name)s %(levelname)s %(message)s')

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(log_format)
    stream_handler.setLevel(logging.DEBUG)
    logger.addHandler(stream_handler)

    file_handler = logging.FileHandler(file_name, mode="a")
    file_handler.setFormatter(log_format)
    file_handler.setLevel(logging.DEBUG)
    logger.addHandler(file_handler)

    return logger
