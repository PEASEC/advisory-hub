from monitoring.connectors.ajax import AjaxRetriever
from monitoring.connectors.csaf import CsafRetriever
from monitoring.connectors.htmlstatic import StaticRetriever
from monitoring.connectors.base import BasicRetriever
from monitoring.connectors.rss import RssRetriever
from monitoring.connectors.htmlurl import HtmlUrlRetriever
from monitoring.connectors.htmlxpath import HtmlXpathRetriever
from datamodel.task import TaskOverview
from logging import Logger
from sqlalchemy import engine


def get_retriever(task: TaskOverview, logger: Logger, engine: engine) -> BasicRetriever:
    if task.type == "static":
        return StaticRetriever(task, logger, engine)
    if task.type == "ajax":
        return AjaxRetriever(task, logger, engine)
    if task.type == "csaf feed":
        return CsafRetriever(task, logger, engine)
    if task.type == "rss":
        return RssRetriever(task, logger, engine)
    if task.type == "url":
        return HtmlUrlRetriever(task, logger, engine)
    if task.type == "xpath":
        return HtmlXpathRetriever(task, logger, engine)
