import monitoring.connectors.base
from datamodel.task import TaskOverview
from logging import Logger
from sqlalchemy import engine
from urllib.parse import urljoin
import requests
import pandas as pd
from lxml import etree
from helper.element import dictify_element


class HtmlUrlRetriever(monitoring.connectors.base.BasicRetriever):
    def __init__(self, task: TaskOverview, logger: Logger, engine: engine):
        super().__init__(task, logger, engine)
        if task.request_method == "":
            self.request_method = "GET"
        else:
            self.request_method = task.request_method
        if not task.selector:
            raise ValueError("This retriever works only if a selector is provided.")

    def retrieve(self) -> pd.DataFrame:
        response = self.make_request()
        dfs = self.handle_response(response)
        df = self.select_df(dfs)
        return df

    def handle_response(self, response) -> [pd.DataFrame]:
        html_parser = etree.HTMLParser(remove_comments=True)
        root = etree.fromstring(response.text, parser=html_parser)
        tree = etree.ElementTree(root, parser=html_parser)
        elements = tree.xpath('//a')
        elements = [dictify_element(element) for element in elements]  # As list of dicts
        elements = self.filter(elements)  # Filtered (using the provided selector)
        elements = self.remove_duplicates(elements)  # Duplicates removed
        df = pd.DataFrame(elements)
        df_abs = self.make_links_absolute(self.url, df)
        return [df_abs]

    def select_df(self, dfs: list) -> pd.DataFrame:
        return dfs[0]

    def make_request(self):
        self.logger.debug(f"{self.netloc} Perform GET request to {self.retrieval_endpoint}")
        response = requests.get(self.retrieval_endpoint, timeout=self.TIMEOUT)
        return response

    def filter(self, elements):
        """Only keep urls that match the provided selector."""
        out_urls = []
        for element in elements:
            url = urljoin(self.url, element.get("a.href"))
            if self.task.selector in url:
                out_urls.append(element)
        return out_urls

    def remove_duplicates(self, elements: [dict]) -> [dict]:
        """
        Does not preserve order according to:
        https://stackoverflow.com/questions/9427163/remove-duplicate-dict-in-list-in-python
        """
        return [dict(t) for t in {tuple(d.items()) for d in elements}]


if __name__ == '__main__':
    from datamodel.task import TaskOverview
    import queue
    from monitoring.retrieverlogging import setup_logger

    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    out_queue = queue.Queue()
    logger = setup_logger("StaticRetrieverTest")
    task = TaskOverview(id=1, type="static", request_method="GET",
                        url="https://www.huawei.com/en/psirt/all-bulletins",
                        retrieval_endpoint="https://www.huawei.com/en/psirt/all-bulletins",
                        selector="https://www.huawei.com/en/psirt/security-advisories/",
                        body=None, header=None,
                        interval=None, lastretrieved=0)
    test1 = HtmlUrlRetriever(task, logger, out_queue)
    urls = test1.retrieve()
    print(urls)
