import monitoring.connectors.base
import requests
import json
import pandas as pd
from datamodel.task import TaskOverview
from logging import Logger
from sqlalchemy import engine


class AjaxRetriever(monitoring.connectors.base.BasicRetriever):
    allowed_methods = ("GET", "POST")

    def __init__(self, task: TaskOverview, logger: Logger, engine: engine, flattening=True):
        super().__init__(task, logger, engine)
        if task.request_method not in self.allowed_methods:
            raise ValueError(f"Request type must be one of: {self.allowed_methods}")
        self.request_method = task.request_method
        self.selector = task.selector  # list of tags / numbers that can be used to iterate through the json tree
        self.flattening = flattening  # indicate if dataframe should be flattened or not

    def retrieve(self) -> pd.DataFrame:
        response = self.make_request()
        potential_results = self.handle_response(response)
        output = self.select_df(potential_results)
        self.normalize(output, self.mapping)
        self.make_links_absolute(self.url, output)
        return output

    def make_request(self) -> requests.Response:
        self.logger.debug(f"{self.netloc} Performing {self.request_method} request to: {self.retrieval_endpoint}")
        if self.request_method == "GET":
            response = requests.get(self.retrieval_endpoint, timeout=self.TIMEOUT, headers=self.header)
        elif self.request_method == "POST":
            if isinstance(self.body, dict):
                response = requests.post(self.retrieval_endpoint, json=self.body, timeout=self.TIMEOUT,
                                         headers=self.header)
            else:
                response = requests.post(self.retrieval_endpoint, data=self.body, timeout=self.TIMEOUT,
                                         headers=self.header)
        else:
            raise ValueError(f"Request method {self.request_method} is not supported.")
        if response.status_code >= 400:
            raise RuntimeError(f"Request returned status code {response.status_code}")
        return response

    def handle_response(self, response: requests.Response) -> [pd.DataFrame]:
        # Code to handle the API response
        self.logger.debug(f"{self.netloc} Handling response from {self.retrieval_endpoint}")

        content = json.loads(response.content)

        outputs = []
        # print(self.selector)
        if self.selector == "" or self.selector is None:
            self.logger.debug(f"{self.netloc} Generating selectors")
            selectors = self.generate_selectors(content)
        else:
            selectors = [self.selector]
        for selector in selectors:
            outputs.append(self.extract_xhr_object(content, selector, True))
        return outputs

    def generate_selectors(self, obj: dict) -> [list]:
        """Return list of lists"""
        # TODO: Be aware of nested lists and build hierarchy of selectors based on that
        self.logger.debug(f"{self.netloc} Searching for lists in response from {self.retrieval_endpoint}")
        found_lists = self.search_list(obj)  # huge list of lists
        # Filter lists
        potential_selectors = [lst[0] for lst in found_lists if len(self.characterize_list(lst[1])) > 5]
        # print(potential_selectors)
        return potential_selectors

    def search_list(self, o, path=None, found_lists=None) -> list:
        """Create a list of all lists that a nested within a JSON and their respective paths"""
        if path is None:
            path = []
        if found_lists is None:
            found_lists = []
        if isinstance(o, list):
            found_lists.append((path, o))
            for num, elm in enumerate(o):
                found_lists = found_lists + self.search_list(elm, path + [num])
            return found_lists
        elif isinstance(o, dict):
            for k, v in o.items():
                found_lists = found_lists + self.search_list(v, path + [k])
            return found_lists
        else:
            return found_lists

    def characterize_list(self, lst: list):
        list_character = [len(elm.keys()) for elm in lst if isinstance(elm, dict)]
        return list_character

    def extract_xhr_object(self, obj, selector=False, flattening=False) -> pd.DataFrame:
        """
        Take JSON, select the relevant subtree and convert it into a pandas dataframe
        :param obj: a JSON document in form of a python dictionary
        :param selector: a list of attributes/integers to select a subtree in the JSON document
        :param flattening: Boolean to indicate if pandas normalize function is applied
        :return:
        """
        if not selector:
            selector = []
        subtree = self.get_subtree_for_selector(obj, selector)
        if flattening:
            df = pd.json_normalize(subtree)
        else:
            df = pd.DataFrame.from_records(subtree)
        return df

    def get_subtree_for_selector(self, obj, selectors: list):
        """Take a nested dict and a list of selectors to iterate through the dict and return the selected subtree"""
        if len(selectors) == 0:
            return obj
        # print(selectors)
        selector = selectors.pop(0)
        if isinstance(obj, dict):
            return self.get_subtree_for_selector(obj[selector], selectors)
        elif isinstance(obj, list) and isinstance(selector, int):
            return self.get_subtree_for_selector(obj[selector], selectors)
        return obj


if __name__ == '__main__':
    # The following code is an example on how to use this class
    from datamodel.task import TaskOverview
    from monitoring.retrieverlogging import setup_logger

    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    logger = setup_logger("AjaxRetrieverTest")
    task = TaskOverview(id=1, type="ajax", request_method="GET", url="abc",
                        retrieval_endpoint="https://api.msrc.microsoft.com/sug/v2.0/en-US/vulnerability?$orderBy=cveNumber desc",
                        selector=None, body=None, header=None,
                        interval=None, lastretrieved=0)

    json_str = '{"operationName":"ListingQuery","variables":{"language":"en","limit":20,"offset":0,"query":"","sort":{"updated":"DESC"},"showMainsiteContents":false,"tags":[],"tagsCriteria":"","type":["ktk_vulnerability_news"]},"query":"query ListingQuery($query: String!, $type: [String!], $language: String!, $sort: JSON, $tags: [[Int]], $tagsCriteria: String, $offset: Int, $limit: Int, $isPromoted: Boolean, $subsitePromoted: Boolean, $showMainsiteContents: Boolean, $doNotLimitToCurrentDomain: Boolean, $domain: String, $customTerms: JSON, $subsite: String, $includeSubsite: [String], $useAnalyticsScoring: Boolean) {\n  listing(\n    query: $query\n    type: $type\n    langcode: $language\n    sort: $sort\n    tags: $tags\n    tagsCriteria: $tagsCriteria\n    offset: $offset\n    limit: $limit\n    isPromoted: $isPromoted\n    subsitePromoted: $subsitePromoted\n    showMainsiteContents: $showMainsiteContents\n    doNotLimitToCurrentDomain: $doNotLimitToCurrentDomain\n    domain: $domain\n    customTerms: $customTerms\n    subsite: $subsite\n    includeSubsite: $includeSubsite\n    useAnalyticsScoring: $useAnalyticsScoring\n  ) {\n    total\n    hits {\n      id\n      ...BasicTeaserFragment\n      ...CustomerServiceTeaserFragment\n      ...NewsTeaserFragment\n      ...PublicationTeaserFragment\n      ...StatisticTeaserFragment\n      ...AlertTeaserFragment\n      ...VulnerabilityTeaserFragment\n      ...RegulationTeaserFragment\n      ...LandingTeaserFragment\n      ...GlossaryTeaserFragment\n      ...ServiceDescriptionTeaserFragment\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment BasicTeaserFragment on Basic {\n  id\n  langcode\n  title\n  type\n  content\n  ingress\n  path\n  domains\n  content_category\n  subsite_name\n  subsite_sitename\n  __typename\n}\n\nfragment CustomerServiceTeaserFragment on CustomerService {\n  id\n  langcode\n  title\n  type\n  content_category\n  page_elements {\n    ... on Text {\n      id\n      type\n      langcode\n      content {\n        ...TextFragment\n        __typename\n      }\n      __typename\n    }\n    ... on Image {\n      id\n      type\n      langcode\n      content {\n        ...ImageFragment\n        __typename\n      }\n      __typename\n    }\n    ... on LinkListElement {\n      id\n      type\n      langcode\n      content {\n        ...LinkListElementFragment\n        __typename\n      }\n      __typename\n    }\n    ... on LinkElement {\n      id\n      type\n      langcode\n      content {\n        ...LinkElementFragment\n        __typename\n      }\n      __typename\n    }\n    ... on AttachmentList {\n      id\n      type\n      langcode\n      content {\n        ...AttachmentListFragment\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TextFragment on Content {\n  width\n  text\n  __typename\n}\n\nfragment ImageFragment on Content {\n  media {\n    type\n    alt\n    derivatives {\n      xs\n      sm\n      md\n      lg\n      __typename\n    }\n    __typename\n  }\n  text\n  caption\n  link {\n    url\n    external\n    __typename\n  }\n  __typename\n}\n\nfragment LinkListElementFragment on Content {\n  links {\n    title\n    url\n    external\n    __typename\n  }\n  __typename\n}\n\nfragment LinkElementFragment on Content {\n  title\n  link {\n    url\n    external\n    extension\n    size\n    title\n    __typename\n  }\n  __typename\n}\n\nfragment AttachmentListFragment on Content {\n  files {\n    name\n    url\n    size\n    extension\n    external\n    __typename\n  }\n  __typename\n}\n\nfragment NewsTeaserFragment on News {\n  id\n  langcode\n  title\n  type\n  created\n  updated\n  content\n  path\n  ingress\n  link_to\n  domains\n  content_category\n  subsite_name\n  subsite_sitename\n  __typename\n}\n\nfragment PublicationTeaserFragment on Publication {\n  id\n  langcode\n  title\n  type\n  publication_type_name\n  publication_date\n  content_category\n  subsite_name\n  subsite_sitename\n  page_elements {\n    ... on Text {\n      id\n      type\n      langcode\n      content {\n        ...TextFragment\n        __typename\n      }\n      __typename\n    }\n    ... on Image {\n      id\n      type\n      langcode\n      content {\n        ...ImageFragment\n        __typename\n      }\n      __typename\n    }\n    ... on LinkListElement {\n      id\n      type\n      langcode\n      content {\n        ...LinkListElementFragment\n        __typename\n      }\n      __typename\n    }\n    ... on LinkElement {\n      id\n      type\n      langcode\n      content {\n        ...LinkElementFragment\n        __typename\n      }\n      __typename\n    }\n    ... on AttachmentList {\n      id\n      type\n      langcode\n      content {\n        ...AttachmentListFragment\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment StatisticTeaserFragment on Statistic {\n  id\n  langcode\n  title\n  type\n  created\n  updated\n  content\n  path\n  ingress\n  domains\n  subsite_name\n  subsite_sitename\n  content_category\n  __typename\n}\n\nfragment AlertTeaserFragment on Alert {\n  id\n  langcode\n  title\n  link_to\n  created\n  updated\n  content\n  path\n  alert_icon\n  ingress\n  serial_number\n  domains\n  content_category\n  subsite_name\n  subsite_sitename\n  __typename\n}\n\nfragment VulnerabilityTeaserFragment on Vulnerability {\n  id\n  langcode\n  title\n  cvss\n  cve_link {\n    title\n    url\n    external\n    __typename\n  }\n  link_to\n  created\n  updated\n  content\n  path\n  serial_number\n  domains\n  subsite_name\n  subsite_sitename\n  content_category\n  __typename\n}\n\nfragment RegulationTeaserFragment on Regulation {\n  id\n  langcode\n  title\n  type\n  text\n  text_more\n  link_to\n  link_text\n  link {\n    title\n    url\n    size\n    extension\n    external\n    __typename\n  }\n  regulation_type_name\n  regulation_number\n  valid_from\n  expire\n  attachment {\n    name\n    url\n    size\n    extension\n    external\n    __typename\n  }\n  domains\n  subsite_name\n  subsite_sitename\n  content_category\n  __typename\n}\n\nfragment LandingTeaserFragment on Landing {\n  id\n  langcode\n  title\n  type\n  path\n  domains\n  content_category\n  subsite_name\n  subsite_sitename\n  __typename\n}\n\nfragment GlossaryTeaserFragment on Glossary {\n  id\n  langcode\n  title\n  path\n  domains\n  content_category\n  subsite_name\n  subsite_sitename\n  __typename\n}\n\nfragment ServiceDescriptionTeaserFragment on ServiceDescription {\n  id\n  langcode\n  title\n  type\n  short_description\n  path\n  domains\n  subsite_name\n  subsite_sitename\n  content_category\n  page_elements {\n    ... on ServiceGatewayLiftupElement {\n      id\n      type\n      langcode\n      content {\n        ...ServiceGatewayLiftupElementFragment\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment ServiceGatewayLiftupElementFragment on Content {\n  service_gateway_id\n  __typename\n}\n"}'

    task2 = TaskOverview(id=2, type="ajax", request_method="GET",
                         url="https://www.mcafee.com/support/?locale=en-US&platform=blank&term=McAfee%20Security%20Bulletin&product=&facet=%2A&fromArticleView=false&isModeSearch=true&page=shell&shell=search#",
                         retrieval_endpoint="https://ejjq-apps6.builder.ocp.oraclecloud.com/ic/builder/rt/csp/live;profile=prod_profile/services/auth/1.1/proxy/salesForceServices/uri/https/mcsg.my.salesforce.com/services/apexrest/KB/Ext/Articles/Search?categoryGroup1=&categoryGroup2=&facet1=&facet2=&locale=en_US&needSummary=true&numArticles=10&offset=0&searchString=McAfee%20Security%20Bulletin",
                         selector="",
                         body=json_str,
                         header="", lastretrieved=0)
    task3 = TaskOverview(id=3, type="ajax", request_method="GET",
                         url="https://trust.zscaler.com/zscaler.net/security-advisories",
                         retrieval_endpoint="https://trust.zscaler.com/api/advisory?cloud=zsn&category=&page=1&date=&datacenter=")

    s1 = AjaxRetriever(task2, logger, None)
    df = s1.retrieve()
    # records = s1.df_to_detail_tasks(df, {"VULNERABILITY": "title", "url": "url2"})
    print(df)
    records = s1.df_to_detail_tasks(df, {})
    print(f"Number of records: {len(records)}")
    # for record in records:
    #    print(record)
