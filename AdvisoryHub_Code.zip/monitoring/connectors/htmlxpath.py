import re

from monitoring.connectors.htmlstatic import StaticRetriever
from datamodel.task import TaskOverview
from logging import Logger
import queue
import pandas as pd
from lxml import etree
from collections import Counter
from helper.element import dictify_element


class HtmlXpathRetriever(StaticRetriever):
    def __init__(self, task: TaskOverview, logger: Logger, out_queue: queue.Queue):
        super().__init__(task, logger, out_queue)
        if task.request_method == "":
            self.request_method = "GET"
        else:
            self.request_method = task.request_method
        if not task.selector:
            raise ValueError("This retriever works only if a selector is provided.")

    def retrieve(self) -> pd.DataFrame:
        response = self.make_request()
        dfs = self.handle_response(response)
        df = self.select_df(dfs)
        df = self.make_links_absolute(self.task.url, df)
        return df

    def handle_response(self, response) -> [pd.DataFrame]:
        html_parser = etree.HTMLParser(remove_comments=True)
        root = etree.fromstring(response.text, parser=html_parser)
        tree = etree.ElementTree(root, parser=html_parser)
        selected_elements = tree.xpath(self.task.selector)
        results = []
        for element in selected_elements:
            attributes = dictify_element(element)
            results.append(attributes)
        results = self.handle_onclick_attributes(results)
        without_outliers = self.remove_outlier_lines(results)
        df = pd.DataFrame.from_records(without_outliers)
        return [df]

    def remove_outlier_lines(self, lines: [dict]) -> [dict]:
        """Remove lines that do not share any keys with the majority of lines."""
        CUTOFF = 0.5

        # Calculate mandatory attributes
        counter = Counter()
        for line in lines:
            counter += Counter(line.keys())

        # Calculate dict{attribute: ratio in how many lines the attribute occurs}
        common_attrib = {attrib: 1 / (len(lines) / cnt) for attrib, cnt in counter.items()}
        # Keep only those attributes which occur in more than lines than CUTOFF
        common_attrib = [k for k, v in common_attrib.items() if v >= CUTOFF]
        # Remove lines that do not have any common attributes
        outliers_removed = [line for line in lines if any([(attrib in line.keys()) for attrib in common_attrib])]
        return outliers_removed

    def handle_onclick_attributes(self, rows: [dict]) -> [dict]:
        """Iterate over list of dictified elements, look for attributes such as div.onclick and extract their target"""
        for row in rows:
            for attribute in row:
                if attribute.endswith(".onclick"):
                    target = re.match(r".*'(.*)'", row[attribute])
                    if target:
                        row[attribute] = target.group(1)
        return rows

    def remove_empty_columns(self, df):
        df = df.dropna(how="all", axis=1, inplace=False)
        df.mask(df.eq("")).dropna(how="all", inplace=True)
        return df


if __name__ == '__main__':
    import queue
    from monitoring.retrieverlogging import setup_logger

    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    out_queue = queue.Queue()
    logger = setup_logger("StaticRetrieverTest")
    task1 = TaskOverview(id=1, type="static", request_method="GET", url="https://www.huawei.com/en/psirt/all-bulletins",
                         retrieval_endpoint="https://www.huawei.com/en/psirt/all-bulletins",
                         selector='//*[@id="tbContent"]/*', body=None, header=None, interval=None, lastretrieved=0)
    task2 = TaskOverview(id=1, type="static", request_method="GET",
                         url="https://www.dlink.com/de/de/support/support-news",
                         retrieval_endpoint="https://www.dlink.com/de/de/support/support-news",
                         selector='//*[@id="loadMoreItems"]/*', body=None, header=None, interval=None, lastretrieved=0)
    task3 = TaskOverview(id=1, type="static", request_method="GET",
                         url="https://www.cisa.gov/news-events/cybersecurity-advisories?f%5B0%5D=advisory_type%3A93",
                         retrieval_endpoint="https://www.cisa.gov/news-events/cybersecurity-advisories?f%5B0%5D=advisory_type%3A93",
                         selector='//article/*', body=None, header=None, interval=None, lastretrieved=0)
    task4 = TaskOverview(id=1, type="static", request_method="GET",
                         url="https://www.tagesschau.de/inland",
                         retrieval_endpoint="https://www.tagesschau.de/inland",
                         selector='//div[contains(@class, "columns twelve m-eight")]', body=None, header=None,
                         interval=None, lastretrieved=0)
    task5 = TaskOverview(id=1, type="static", request_method="GET",
                         url="https://www.fortiguard.com/psirt",
                         retrieval_endpoint="https://www.fortiguard.com/psirt",
                         selector='//section[contains(@class, "table-body")]/div/*', body=None, header=None,
                         interval=None, lastretrieved=0)
    task6 = TaskOverview(id=1, type="static", request_method="GET",
                         url="https://www.fortiguard.com/psirt",
                         retrieval_endpoint="https://www.fortiguard.com/psirt",
                         selector='//section[contains(@class, "table-body")]/div/*', body=None, header=None,
                         interval=None, lastretrieved=0)
    task7 = TaskOverview(id=1, type="static", request_method="GET",
                         url="https://confluence.atlassian.com/sourcetreekb/security-advisories-900820352.html",
                         retrieval_endpoint="https://confluence.atlassian.com/sourcetreekb/security-advisories-900820352.html",
                         selector='//div/ul[contains(@class, "childpages-macro conf-macro output-block")]/li/a',
                         body=None, header=None,
                         interval=None, lastretrieved=0)
    task8 = TaskOverview(id=1, type="static", request_method="GET",
                         url="https://www.videolan.org/security/",
                         retrieval_endpoint="https://www.videolan.org/security/",
                         selector='//dl',
                         body=None, header=None,
                         interval=None, lastretrieved=0)
    task9 = TaskOverview(id=1, type="static", request_method="GET",
                         url="https://httpd.apache.org/security/vulnerabilities_24.html",
                         retrieval_endpoint="https://httpd.apache.org/security/vulnerabilities_24.html",
                         selector='//dl/dt',
                         body=None, header=None,
                         interval=None, lastretrieved=0)
    task10 = TaskOverview(id=1, type="static", request_method="GET",
                          url="https://blog.talosintelligence.com/",
                          retrieval_endpoint="https://blog.talosintelligence.com/",
                          selector='//div[contains(@class, "post-wrapper")]',
                          body=None, header=None,
                          interval=None, lastretrieved=0)
    task11 = TaskOverview(id=1, type="static", request_method="GET",
                          url="https://sec-consult.com/vulnerability-lab/",
                          retrieval_endpoint="https://sec-consult.com/vulnerability-lab/",
                          selector='//article[contains(@class, "news-item")]',
                          body=None, header=None,
                          interval=None, lastretrieved=0)
    task12 = TaskOverview(id=1, type="static", request_method="GET",
                          url="https://www.fortiguard.com/psirt",
                          retrieval_endpoint="https://www.fortiguard.com/psirt",
                          selector='//section[contains(@class, "table-body")]/div/div[contains(@class, "row")]',
                          body=None, header=None,
                          interval=None, lastretrieved=0)
    s1 = HtmlXpathRetriever(task12, logger, out_queue)
    resp = s1.retrieve()
    s1.make_links_absolute(s1.url, resp)

    print(resp)
