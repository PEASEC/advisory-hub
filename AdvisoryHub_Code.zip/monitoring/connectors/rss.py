import requests

from monitoring.connectors.ajax import AjaxRetriever
import pandas as pd
from datamodel.task import TaskOverview
from logging import Logger
from sqlalchemy import engine
from io import StringIO


class RssRetriever(AjaxRetriever):
    def __init__(self, task: TaskOverview, logger: Logger, engine: engine, flattening=True):
        AjaxRetriever.__init__(self, task, logger, engine, flattening=True)
        self.content_type = None
        self.flattening = flattening

    def retrieve(self) -> pd.DataFrame:
        response = self.make_request()
        content_type = response.headers["Content-Type"]
        interesting_tables = self.handle_response(response)
        df = self.select_df(interesting_tables)
        self.normalize(df, self.mapping)
        return df

    def handle_response(self, response: requests.Response) -> [pd.DataFrame]:
        # Read df from xml with a xpath selector that looks for all tags containing 'item'
        df = pd.read_xml(StringIO(response.text), xpath="//*[contains(name(), 'item')]")
        return [df]

    def select_df(self, dfs):
        return dfs[0]


if __name__ == '__main__':
    from datamodel.task import TaskOverview
    import queue
    from monitoring.retrieverlogging import setup_logger

    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    out_queue = queue.Queue()
    logger = setup_logger("RssRetrieverTest")

    user_agent = '{"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0"}'

    url1 = "https://www.trumpf.com/de_DE/?tx_trumpfdownloads_downloadlist%5BcontentId%5D=536870&type=1645055335&cHash=918356552ea6479eacac3f71295d91f5"
    url2 = "https://www.zerodayinitiative.com/rss/published/"
    url3 = "https://cert.europa.eu/publications/security-advisories-rss"
    url4 = "https://www.phpmyadmin.net/security/feed/"
    url5 = "https://www.debian.org/security/dsa"
    task1 = TaskOverview(id=1, type="csaf feed", request_method="GET",
                         url=url3,
                         retrieval_endpoint=url3,
                         selector=None, body=None, header=user_agent,
                         interval=None, lastretrieved=0)
    task2 = TaskOverview(id=1, type="csaf feed", request_method="GET",
                         url=url5,
                         retrieval_endpoint=url5,
                         selector=None, body=None, header=user_agent,
                         interval=None, lastretrieved=0,
                         mapping='{"title": "xx_identifier", "link": "xx_url", "description": "xx_summary", "pubDate": "xx_published", "guid": "other", "dc:creator.@xmlns:dc": "other", "dc:creator.#text": "other"}')

    s1 = RssRetriever(task2, logger, out_queue)
    df = s1.retrieve()
    output_records = s1.df_to_detail_tasks(df, s1.mapping)
    print(output_records)
