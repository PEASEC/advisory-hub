import json
import re
import threading
import time
from datetime import datetime, timezone
from logging import Logger
from urllib.parse import urlparse

import pandas as pd
import requests
from sqlalchemy import engine, and_
from sqlalchemy.orm import Session

from datamodel.task import TaskOverview, TaskDetail
from helper.column_normalizer import mapping, normalizer, process_line


class BasicRetriever(threading.Thread):
    TIMEOUT = 30  # Wait maximum 30 seconds until requests time out

    def __init__(self, task: TaskOverview, logger: Logger, engine: engine):
        super(BasicRetriever, self).__init__()
        self.logger = logger
        self.engine = engine
        self.session = None
        self.task = task
        if task.url == "":
            self.url = task.retrieval_endpoint
        else:
            self.url = task.url
        self.retrieval_endpoint = task.retrieval_endpoint
        self.netloc = urlparse(self.url).netloc

        try:
            mapping = json.loads(task.mapping)
            self.mapping = {k: v for k, v in mapping.items() if v != "other"}  # Do not rename other columns
        except TypeError:
            self.mapping = None
        except json.decoder.JSONDecodeError:
            self.mapping = None
        self.logger.debug(f"{self.netloc} INITIATED with url {self.url} - {type(self.url)}")

        self.header = self.prepare_header(task.header)
        self.body = self.prepare_body(task.body)

    def prepare_header(self, header: str) -> dict:
        if header:
            try:
                return json.loads(header)
            except json.decoder.JSONDecodeError as e:
                self.logger.warning(f"{self.netloc} Failed to parse request header during retrieval of "
                                    f"{self.retrieval_endpoint}: {e}")
        return {}

    def prepare_body(self, body: str) -> dict | str:
        if not body:
            return body

        # Prepare body to be parsed (translate Python dict into json string)
        body = body.replace("\r\n", "")
        body = body.replace("\n", "")
        body = body.replace("False", "false")
        body = body.replace("True", "true")
        body = " ".join(body.split())

        try:
            return json.loads(body)
        except json.decoder.JSONDecodeError as e:
            self.logger.warning(f"{self.netloc} Failed to parse request body during retrieval of "
                                f"{self.retrieval_endpoint}: {e}")
            return body

    def run(self):
        try:
            self.session = Session(self.engine)
            self.task = self.session.query(TaskOverview).where(TaskOverview.id == self.task.id).first()  # Refresh ORM
            output = self.retrieve()
            output_records = self.df_to_detail_tasks(output, self.mapping)
            assert isinstance(output_records, list)
            self.write_detail_tasks_to_db(output_records)
        except Exception as e:
            error_message = f"Retrieval fail due to {e}"
            self.task.statusmessage = error_message
            self.session.commit()
            self.logger.error(f"{self.netloc} - {error_message}")
        self.logger.debug(f"{self.netloc} TERMINATED")
        # This could be needed to fix the bug: "QueuePool limit of size 5 overflow 10 reached, connection timed out"
        self.session.close()

    def write_detail_tasks_to_db(self, result: [dict]):
        self.task.lastretrieved = str(datetime.now(timezone.utc))
        self.task.statusmessage = ""
        self.session.commit()  # write update of task_done.lastretrieved
        print(f"There is a response available for {self.task.url} with {len(result)} lines")

        t0 = time.time()
        for line in result:
            # Promote well-known attribute types to columns
            first_seen = str(datetime.now(timezone.utc))
            column_attributes = process_line(line)

            prior = self.session.query(TaskDetail).where(and_(
                TaskDetail.url == column_attributes["url"],
                TaskDetail.identifier == column_attributes["identifier"])
            ).first()

            if prior:
                # prior.lastretrieved = first_seen  # TODO: Change line into something that makes sense
                # self.session.commit()
                pass
            else:
                new_task = TaskDetail(**column_attributes, firstseen=first_seen, lastretrieved=None,
                                      domain=self.task.url, properties=str(line))
                self.session.add(new_task)
                self.session.commit()

    def retrieve(self) -> pd.DataFrame:
        output = pd.DataFrame()
        return output

    def make_request(self) -> requests.Response:
        # Code to make the API request
        response = requests.Response()
        return response

    def handle_response(self, response) -> [pd.DataFrame]:
        # Code to handle the API response
        output = []
        return output

    def normalize(self, df: pd.DataFrame, mapping: dict) -> None:
        """Normalizes overview dataframe inplace:"""
        # TODO: Normalize based on content
        # TODO: Do url normalization
        if not mapping:
            mapping = {}
        df.rename(inplace=True, columns=mapping)  # Rename all columns according to normalizer dict

    def determine_column_content(self, df: pd.DataFrame) -> dict:
        """
        Take a dataframe and predict what type of content is in columns.
        Return mapping: (original column name: detected column name)
        """
        columns = df.columns
        mapping = {col: normalizer[col.lower()] for col in columns}
        return mapping

    def df_to_detail_tasks(self, df: pd.DataFrame, column_mapping: dict) -> [dict]:
        """Transform dataframe to detail tasks, rename attributes/columns so that they start with xx"""
        if column_mapping is not None:
            df.rename(columns=column_mapping, inplace=True)  # Rename columns according to dict
        records = df.to_dict("records")
        return records

    def select_df(self, dfs: list) -> pd.DataFrame:
        """
        Choose best df from multiple options (when there is more than one table on page).
        Selection is made based on overall table size.
        """

        table_shapes = [df.shape for df in dfs]
        self.logger.debug(f"Potential shapes for selection: {table_shapes}")
        dfs = [df for df in dfs if not df.empty]  # Filter out empty data frames
        if len(dfs) == 0:
            return pd.DataFrame()
        else:
            best_df = max(dfs, key=lambda df: self.columns_of_interest(df.columns))
            return best_df

    def columns_of_interest(self, columns) -> int:
        normal_cols = mapping.keys()
        try:
            # In rare cases this fails due to column names being tuples even when they should be flat
            matches = len([col for col in columns if col.lower() in normal_cols])
        except AttributeError as e:
            matches = 0
        return matches

    def set_last_retrieval_field(self, session, page):
        page.last_retrieval_field = int(time.time())

    @staticmethod
    def promote_headers(df: pd.DataFrame) -> pd.DataFrame:
        """If column headers are int typed, promote first row of data into headers."""

        # Check if headers are already of tuple type
        if all([isinstance(col, tuple) for col in df.columns.tolist()]):
            return df

        df.columns = df.iloc[0]  # Set header to values in first row
        df = df[1:]  # Remove first row if column headers are int based
        return df

    @staticmethod
    def combine_urls(url, path):
        """Take an url (host) and a path and combine them into an absolute url."""

        if not isinstance(path, str):
            return path

        if path.startswith("https:") or path.startswith("http:"):
            return path

        url_p = urlparse(url)
        combined = url_p.scheme + "://" + url_p.netloc + ("/" + path).replace("//", "/")
        return combined

    def make_links_absolute(self, url: str, df: pd.DataFrame) -> pd.DataFrame:
        """Take a url and a dataframe and make all relative links absolute."""
        names_of_rel_columns = self.find_rel_url_column(df)
        self.logger.debug(f"Names of rel columns: {names_of_rel_columns}")

        # TODO:
        # 1. Check if column contains link/url/path
        # 2. Check ifo column ends with "Link"

        for col in names_of_rel_columns:
            # Get all values in column as list of strings
            column_entries_str = [entry for entry in df[col].tolist() if isinstance(entry, str)]

            # Handle case where retriever crashes because column is empty
            if not column_entries_str:
                continue

            # Make 1 request to first assembled url to test if it worked
            test_url = self.combine_urls(url, column_entries_str[0])
            response = None
            try:
                response = requests.get(test_url, headers=self.header)
                a = f"Request yielded statuscode {response.status_code}"
            except Exception as e:
                a = e
            if response and response.status_code not in [404, 500]:
                self.logger.debug(f"{self.netloc} Test request to {test_url} worked")
                df[col] = df[col].map(lambda x: self.combine_urls(url, x))
            else:
                self.logger.debug(f"Test request to {test_url} failed with response code {a}")

        return df

    @staticmethod
    def is_abs_url(x):
        """Check if str is url, return url if it is an url, None otherwise."""
        if isinstance(x, str) and x.startswith("http"):
            return True
        else:
            return False

    @staticmethod
    def is_rel_url(x):
        """Check if str is a relative url, return url if it is an url, None otherwise."""
        if isinstance(x, str):
            if x.startswith("/"):
                return True
            if "/" in x and " " not in x.strip() and not x.strip().startswith("http"):
                return True
        else:
            return False

    def make_column_names_ascii(self, df: pd.DataFrame) -> None:
        """Remove special characters from column names."""
        df.columns = [re.sub(r'[^\x00-\x7F]+', ' ', col) for col in df.columns]

    def find_abs_url_column(self, df: pd.DataFrame) -> list:
        """
        Take a dataframe representing an overview page and find the column that most likely contains the links to the
        detail pages
        """

        abs_url_columns = []
        for num, col in enumerate(df.columns):
            self.logger.debug(f"{self.netloc} Iterating over column {col} to search for absolute url column.")
            # If almost all values in column look like a url, column probably is an url column
            true_count = df[col].map(lambda x: self.is_abs_url(x)).sum()
            column_length = len(df[col].to_list())
            url_ratio = true_count / column_length
            if url_ratio >= 0.95:
                abs_url_columns.append(col)
        return abs_url_columns

    def find_rel_url_column(self, df: pd.DataFrame) -> list:
        """Return the names of those columns that contain relative urls."""
        new_df = pd.DataFrame()
        rel_url_columns = []
        url_indicators = ["url", "href", "link", "onclick"]
        for num, col in enumerate(df.columns):
            if any(ind in col.lower() for ind in url_indicators):  # Check if any indicator in column name
                # Check all values if they could be a relative url
                # new_df[col] = df[col].map(lambda x: self.is_abs_url(x))
                # if new_df[col].notnull().eq(False).all():
                rel_url_columns.append(col)

        return rel_url_columns

    def simplify_urls(self, df: pd.DataFrame):
        """
        Take a df containing multiple columns with different or identical urls.
        Select the column that is most likely pointing to the detail page of the vulnerabilities.
        Function works inplace.
        """
        # Check all columns containing urls and eliminate identical columns
        url_columns = self.find_abs_url_column(df)
        for col1 in url_columns:
            for col2 in url_columns:
                if col1 != col2:
                    # Make sure that columns to compare were not already deleted
                    if col1 in df.columns and col2 in df.columns:
                        # Compare columns and delete them form df if their content is identical
                        if df[col1].equals(df[col2]):
                            df.drop(col2, axis=1, inplace=True)

        url_columns = self.find_abs_url_column(df)

        if len(url_columns) == 0:
            # This should not happen
            return
        if len(url_columns) == 1:
            # Rename column
            df.rename(columns={url_columns[0]: "xx_url"}, inplace=True)
            return
        else:
            # Select url column with most distinct values
            unique_values = {col: df[col].nunique() for col in url_columns}
            col_with_max_nunique = max(unique_values, key=unique_values.get)
            df.rename(columns={col_with_max_nunique: "xx_url"}, inplace=True)
