import monitoring.connectors.base
import pandas as pd
from io import StringIO
from bs4 import BeautifulSoup
import requests
# from helper.tables import flatten_link_df, promote_headers, make_links_absolute, simplify_urls
from datamodel.task import TaskOverview
from logging import Logger
import itertools
from urllib.parse import urljoin
from sqlalchemy import engine


class StaticRetriever(monitoring.connectors.base.BasicRetriever):
    def __init__(self, task: TaskOverview, logger: Logger, engine: engine):
        super().__init__(task, logger, engine)
        if task.request_method == "":
            self.request_method = "GET"
        else:
            self.request_method = task.request_method

    def retrieve(self) -> pd.DataFrame:
        response = self.make_request()
        interesting_tables = self.handle_response(response)  # promote headers, flatten links
        output = self.select_df(interesting_tables)
        self.make_column_names_ascii(output)
        self.simplify_urls(output)
        self.normalize(output, self.mapping)
        return output

    def make_request(self):
        self.logger.debug(f"{self.netloc} Perform GET request to {self.retrieval_endpoint}")
        response = requests.get(self.retrieval_endpoint, timeout=self.TIMEOUT)
        return response

    def handle_response(self, response: requests.Response) -> [pd.DataFrame]:
        # Return list of potentially interesting tables
        self.logger.debug(f"{self.netloc} Process response from {self.retrieval_endpoint}")
        soup = BeautifulSoup(response.content, 'html.parser')
        tables = pd.read_html(StringIO(str(soup)), extract_links="all")

        self.logger.debug(f"{self.netloc} Found {len(tables)} tables in html response")

        tables_out = []
        tables = [self.promote_headers(df) for df in tables]
        for tab in tables:
            tab_ph = self.promote_headers(tab)
            tab_f = self.flatten_link_df(tab_ph)
            tables_out.append(tab_f)
        # tables = [promote_headers(df) for df in tables]
        return tables_out

    def make_abs(self, url):
        if url is None:
            return None
        if url == "":
            return ""
        if url.startswith("http"):
            return url
        else:
            return urljoin(self.url, url)

    def flatten_link_df(self, df: pd.DataFrame) -> pd.DataFrame:
        """Transform a Dataframe containing tuples (content, link) into a Dataframe where links are in extra columns."""

        # Generate a df that contains all cell types and return it as a nested list
        all_types = df.map(lambda x: isinstance(x, tuple)).values.tolist()
        all_types_flat = list(itertools.chain(*all_types))
        if False in set(all_types_flat):
            # Do nothing with df if there is any cell that does not contain a tuple
            return df

        new_df = pd.DataFrame()

        for num, column in enumerate(df.columns):
            try:
                # Flatten column names since the may also look like this: (name, link)
                column_name = column[0]
            except TypeError:
                column_name = column
            # In rare cases there are nested tuples, no idea why
            if isinstance(column, tuple) and any(isinstance(el, tuple) for el in column):
                column_name = column[0][0]

            try:
                url_col = column_name + " Link"
                # Split columns into two columns: one for text, one for links
                new_df[[column_name, url_col]] = pd.DataFrame(df.iloc[:, num].tolist(), index=df.index)
                # Make urls absolute
                new_df[url_col] = new_df[url_col].apply(lambda link: self.make_abs(link))

            except Exception as e:
                # Return empty df in case of error
                self.logger.info(f"{self.netloc} Error while getting links from df: {e}")
                return pd.DataFrame()

        new_df.dropna(how="all", axis=1, inplace=True)  # Drop all empty columns

        return new_df

    def print_table(self, tables):
        for num, tab in enumerate(tables):
            print(f"Printing table {num}")
            print(tab)
            print(tab.shape)
            print(tab.iloc[0, :].values.flatten().tolist())


if __name__ == "__main__":
    # The following code is an example on how to use this class
    from datamodel.task import TaskOverview
    from monitoring.retrieverlogging import setup_logger

    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    logger = setup_logger("StaticRetrieverTest")
    task = TaskOverview(id=1, type="static", request_method="GET", url="https://security.snyk.io/vuln",
                        retrieval_endpoint="https://security.snyk.io/vuln", selector=None, body=None, header=None,
                        interval=None, lastretrieved=0)
    task2 = TaskOverview(id=2, type="ajax", request_method="GET",
                         url="https://de.codesys.com/security/security-meldungen.html",
                         retrieval_endpoint="https://de.codesys.com/security/security-meldungen.html", selector=None,
                         body=None, header=None,
                         interval=None, lastretrieved=0)
    mapping = '{"Type": "other", "Severity": "xx_severity", "Advisory": "xx_identifier", "Summary": "xx_title", "Release Date": "xx_published"}'
    task3 = TaskOverview(id=3, type="static", request_method="GET",
                         url="https://linux.oracle.com/ords/f?p=105:21",
                         retrieval_endpoint="https://linux.oracle.com/ords/f?p=105:21", selector=None,
                         body=None, header=None, mapping=mapping,
                         interval=None, lastretrieved=0)
    s1 = StaticRetriever(task3, logger, None)
    df = s1.retrieve()
    recs = s1.df_to_detail_tasks(df, s1.mapping)
    print(recs)
    # response = s1.make_request()
    # interesting_tables = s1.handle_response(response)
    # output = s1.select_df(interesting_tables)

    # records = s1.df_to_detail_tasks(df, {"VULNERABILITY": "title", "url": "url2"})
    # for record in records:
    #    print(record)
