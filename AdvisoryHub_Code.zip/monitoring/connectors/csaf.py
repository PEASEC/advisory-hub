from monitoring.connectors.htmlstatic import StaticRetriever
from monitoring.connectors.ajax import AjaxRetriever
import pandas as pd
from datamodel.task import TaskOverview
from logging import Logger
from sqlalchemy import engine


class CsafRetriever(AjaxRetriever, StaticRetriever):
    def __init__(self, task: TaskOverview, logger: Logger, engine: engine, flattening=True):
        AjaxRetriever.__init__(self, task, logger, engine, flattening=True)
        self.content_type = None
        # This can be either "text/html" or "application/json" (depending on the particular feed)
        if not self.mapping:
            self.mapping = {}

    def retrieve(self) -> pd.DataFrame:
        response = self.make_request()
        content_type = response.headers["Content-Type"]
        # TODO: Make the following line more robust
        if content_type.lower() in ["application/json", "text/plain; charset=utf-8"]:
            # Response is json
            potential_results = AjaxRetriever.handle_response(self, response)
            output = AjaxRetriever.select_df(self, potential_results)
            output = parse_link_column(output)
            AjaxRetriever.normalize(self, output, {**self.mapping, **{"self": "url"}})
        elif content_type.lower() == "text/html":
            # Response is html
            interesting_tables = StaticRetriever.handle_response(self, response)  # promote headers, flatten links
            output = StaticRetriever.select_df(self, interesting_tables)
            self.make_column_names_ascii(output)
            StaticRetriever.simplify_urls(self, output)
            # StaticRetriever.normalize(self, output, self.mapping)
            output = filter_file_extension(output)
        else:
            # Unknown content type in response header
            self.logger.warning(f"Unrecognized content: {content_type}")
            output = pd.DataFrame()
        return output


def link_cell_to_tuple(cell) -> (str, str, str):
    records = {}
    for element in cell:
        records[element["rel"]] = element["href"]

    return records.get("self"), records.get("signature"), records.get("hash")


def filter_file_extension(df: pd.DataFrame) -> pd.DataFrame:
    """Return only rows that point to files ending with .json extension."""
    df = df[df["xx_url"].apply(lambda x: isinstance(x, (str, bytes)))]
    df = df[df["xx_url"].str.endswith(".json")]
    return df


def parse_link_column(df: pd.DataFrame) -> pd.DataFrame:
    """Parse link column and split it into three columns: self, signature, hash."""
    column = df["link"]
    column_tup = column.apply(lambda x: link_cell_to_tuple(x))
    df2 = pd.DataFrame.from_records(column_tup, columns=["self", "signature", "hash"])
    df.drop("link", axis=1, inplace=True)
    new_df = pd.concat([df, df2], axis=1)
    return new_df


if __name__ == '__main__':
    from datamodel.task import TaskOverview
    from monitoring.retrieverlogging import setup_logger

    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    logger = setup_logger("CsafRetrieverTest")

    task1 = TaskOverview(id=1, type="csaf feed", request_method="GET",
                         url="https://cert-portal.siemens.com/productcert/csaf/ssa-feed-tlp-white.json",
                         retrieval_endpoint="https://cert-portal.siemens.com/productcert/csaf/ssa-feed-tlp-white.json",
                         selector=None, body=None, header=None,
                         interval=None, lastretrieved=0)
    task2 = TaskOverview(id=2, type="csaf feed", request_method="GET",
                         url="https://access.redhat.com/security/data/csaf/v2/advisories/2024/",
                         retrieval_endpoint="https://access.redhat.com/security/data/csaf/v2/advisories/2024/",
                         selector=None, body=None, header=None,
                         interval=None, lastretrieved=0)
    task3 = TaskOverview(id=3, type="csaf feed", request_method="GET",
                         url="https://www.cisco.com/.well-known/csaf/2024/",
                         retrieval_endpoint="https://www.cisco.com/.well-known/csaf/2024/",
                         selector=None, body=None, header=None,
                         interval=None, lastretrieved=0)

    s1 = CsafRetriever(task3, logger, None)
    df = s1.retrieve()
    # print(df)

    # df = parse_link_column(df)
    print(df)

    # print(df_flattened)
