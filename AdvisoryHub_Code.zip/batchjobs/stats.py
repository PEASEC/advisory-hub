from sqlalchemy import create_engine, engine
from sqlalchemy.sql import text
from sqlalchemy.orm import Session
import csv
from batchjobs.batchbase import BatchBase
from datetime import timedelta


class StatsCreator(BatchBase):
    def __init__(self, interval: timedelta, engine: engine):
        super(StatsCreator, self).__init__(interval)
        self.session = Session(engine)

    def action(self):
        self.create_chart1("interface/static/advisory_analysis.csv")

    def create_chart1(self, filepath):
        statement = text("SELECT substr(detailpages.firstseen, 0, 11), COUNT(1) "
                         "FROM detailpages GROUP BY substr(detailpages.firstseen, 0, 11);")
        chart1 = self.session.execute(statement).all()
        with open(filepath, "w", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["Date", "Value"])
            for date, value in chart1:
                writer.writerow([date, value])


if __name__ == '__main__':
    engine = create_engine("sqlite:///resources/task.db", echo=False)
    abc = StatsCreator(timedelta(minutes=1), engine)
    abc.start()
