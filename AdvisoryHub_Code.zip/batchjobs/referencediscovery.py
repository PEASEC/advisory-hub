import csv
import json
import os
from collections import Counter
from datetime import timedelta
from urllib.parse import urlparse

from batchjobs.batchbase import BatchBase


class ReferenceStatsCreator(BatchBase):
    color_bootstrap_red = "#dc3545"
    color_bootstrap_green = "#69b3a2"

    def __init__(self, interval: timedelta):
        super(ReferenceStatsCreator, self).__init__(interval)
        self.root_path = "resources/download-details"

    def action(self):
        references, examples = self.analyze_csaf_references()
        filepath = "interface/static/references_analysis.csv"
        self.generate_csv(filepath, references, examples)
        print("Done")

    def get_all_file_paths(self) -> [str]:
        """Get all paths of all downloaded/generated csaf files."""
        directories = []
        for name in os.listdir(self.root_path):
            path = f"{self.root_path}/{name}"
            if os.path.isdir(path):
                directories.append(path)

        all_file_paths = []
        for directory in directories:
            for file in os.listdir(directory):
                all_file_paths.append(f"{directory}/{file}")

        return all_file_paths

    def analyze_csaf_references(self) -> ([str], {}):
        """Iterate through all stored csaf files and extract all reference domains and one example path per domain."""
        all_references = []
        example_dict = {}

        file_paths = self.get_all_file_paths()
        for fp in file_paths:
            with open(fp, "r") as f:
                json_file = json.load(f)
                references_lst = json_file["document"]["references"]
                for ref in references_lst:
                    netloc = urlparse(ref["url"]).netloc
                    if netloc not in example_dict.keys():
                        example_dict[netloc] = ref["url"]  # This line stores 1 example url in the dict per netloc
                    all_references.append(netloc)
        return all_references, example_dict

    def generate_csv(self, filepath: str, all_references: list, example_dict: dict):
        monitored_providers = []
        for name in os.listdir(self.root_path):
            monitored_providers.append(name)

        ref_cntr = Counter(all_references)
        with open(filepath, "w", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["Provider", "Value", "Color", "Example"])
            for provider, count in ref_cntr.most_common(50):
                example = example_dict[provider]
                if provider in monitored_providers:
                    color = self.color_bootstrap_green
                else:
                    color = self.color_bootstrap_red
                writer.writerow([provider, count, color, example])


if __name__ == '__main__':
    abc = ReferenceStatsCreator(timedelta(seconds=30))
    abc.start()
