import json
import os
import time
from datetime import timedelta, datetime

import dateutil.parser
from sqlalchemy import create_engine, Engine
from sqlalchemy.orm import Session

from batchjobs.batchbase import BatchBase
from datamodel.csaf import Document, Vulnerability, Base, LastCheck, Vendor


class PreviewCreator(BatchBase):
    def __init__(self, engine: Engine, interval: timedelta):
        super(PreviewCreator, self).__init__(interval)
        self.session = Session(engine)
        self.lastchecked = self.load_last_check()

    def action(self):
        print("Loop started:")
        ts = datetime.now()
        changed_files = get_changed_files("resources/download-details", since=self.lastchecked)
        for path in changed_files:
            try:
                analyze(self.session, path)
            except Exception as e:
                pass
        self.update_last_check(ts)
        time.sleep(self.interval.seconds)

    def ago(self, td: timedelta) -> datetime:
        """Take a timedelta and calculate timestamp in the past"""
        now = datetime.now()
        backthen = now - td
        return backthen

    def load_last_check(self) -> datetime:
        lastcheck = self.session.query(LastCheck).first()
        if lastcheck:
            return dateutil.parser.parse(lastcheck.date)
        else:
            return self.ago(timedelta(days=365))

    def update_last_check(self, ts: datetime) -> None:
        self.lastchecked = ts
        lastcheck = self.session.query(LastCheck).first()
        if lastcheck:
            lastcheck.updated = ts
        else:
            self.session.add(LastCheck(date=ts))
        self.session.commit()


def analyze(session: Session, path: str):
    """Take a path to a CSAF file and add it to the database if it doesn't exist yet'"""
    with open(path, "r") as file:
        j1 = json.load(file)
    data = j1["data"]
    document_new = document_obj_from_csaf(path, data, session)
    prior = session.query(Document).where(Document.identifier == document_new.identifier).where(
        Document.provider == document_new.provider).first()
    if not prior:
        session.add(document_new)
        session.commit()


def get_changed_files(directory: str, since: datetime) -> [str]:
    """Return all paths of files that have been modified after the 'since' date."""

    result_paths = []
    for path, subdirs, files in os.walk(directory):
        for name in files:
            filepath = os.path.join(path, name).replace("\\", "/")
            changed_unix_ts = os.path.getmtime(os.path.join(path, name))
            changed_dt = datetime.fromtimestamp(changed_unix_ts)
            if changed_dt > since:
                print(f"{filepath} - Changed: {changed_dt}")
                result_paths.append(filepath)

    return result_paths


def document_obj_from_csaf(path: str, csaf: dict, session: Session):
    """Take a path and a csaf dict, and push a preview Document object to the DB."""

    extraction_paths = {
        "provider": ["document", "publisher", "namespace"],
        "title": ["document", "title"],
        "identifier": ["document", "tracking", "id"],
        "published": ["document", "tracking", "initial_release_date"],
        "severity": ["document", "aggregate_severity", "text"]
    }

    # Use extraction paths and extract properties from csaf dict
    # The extracted data is stored in creation_attributes which is later used to create the preview Document object
    creation_attributes = {attrib: nested_get(csaf, path) for attrib, path in extraction_paths.items()}

    vulnerabilities_str = []
    if csaf.get("vulnerabilities"):
        vulnerabilities_str = [vuln.get("cve") for vuln in csaf["vulnerabilities"] if vuln.get("cve")]

    vulnerabilities = []
    for vulnerability_name in list(set(vulnerabilities_str)):

        prior = session.query(Vulnerability).where(Vulnerability.identifier == vulnerability_name).first()
        if prior:
            vulnerabilities.append(prior)
        else:
            vulnerability = Vulnerability(identifier=vulnerability_name)
            vulnerabilities.append(vulnerability)

    # Get vendor names
    vendors_str = []
    branches = csaf["product_tree"].get("branches")
    if branches:
        for branch in branches:
            if branch.get("category") == "vendor":
                vendor = branch.get("name")
                if vendor:
                    vendors_str.append(vendor.lower())

    # For every vendor name, lookup vendor obj in preview DB to make relation between Document obj and Vendor objs
    vendors = []
    for vendor in list(set(vendors_str)):
        prior = session.query(Vendor).where(Vendor.name == vendor).first()
        if prior:
            vendors.append(prior)
        else:
            vendor_obj = Vendor(name=vendor)
            vendors.append(vendor_obj)

    last_update_date = csaf["document"]["tracking"]["revision_history"][-1]["date"]
    url = csaf["document"]["references"][0]["url"]

    downloaded = datetime.now().replace(microsecond=0).isoformat()

    arguments = creation_attributes | {"filepath": path, "vulnerabilities": vulnerabilities,
                                       "updated": last_update_date, "downloaded": downloaded,
                                       "url": url, "vendors": vendors}

    identifier = creation_attributes.get("identifier", "")
    provider = creation_attributes.get("provider", "")

    # Check if document is already in preview DB, if not push it to the DB
    document = session.query(Document).where(Document.identifier == identifier).where(
        Document.provider == provider).first()
    if not document:
        document = Document(**arguments)
        session.add(document)
        try:
            session.commit()
        except Exception as e:
            print(f"Exception Occurred while writing to CSAF DB: {e}")
            session.rollback()


def nested_get(dictionary: dict, keys: [str]) -> str | None:
    """Take a nested dictionary and a list of keys, iterate through the dictionary by using the key."""
    res = dictionary.get(keys[0])
    if not res:
        return None
    if len(keys) > 1:
        res = nested_get(res, keys[1:])
    return res


if __name__ == '__main__':
    engine = create_engine("sqlite:///resources/csaf.db", echo=False)
    Base.metadata.create_all(engine)

    p1 = PreviewCreator(engine=engine, interval=timedelta(seconds=1))
    p1.start()

    # analyze(session)
