import urllib.parse
import re
import io
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from datamodel.cpe import Base, Vendor, Product

db_path = "sqlite:///resources/cpe.db"
engine = create_engine(db_path, echo=False)


def fill_db(session: Session):
    vp = {}
    filename = "resources/official-cpe-dictionary_v2.3.xml"
    with io.open(filename, mode="r", encoding="utf-8") as file:
        for num, line in enumerate(file):
            cpe_m = re.search('<cpe-item name="(.*)">', line)

            if cpe_m:
                cpe_str = cpe_m.group(1).replace("cpe:/", "cpe:2.3:")
                cpe_str = urllib.parse.unquote(cpe_str, encoding='utf-8', errors='replace')

                # Split CPE string into elements
                cpe_lst = cpe_str.split(":")
                cpe_type = cpe_lst[2]
                cpe_vendor = cpe_lst[3]
                cpe_product = cpe_lst[4]

                if cpe_vendor in vp.keys():
                    vp[cpe_vendor].append(cpe_product)
                else:
                    vp[cpe_vendor] = [cpe_product]

    for vendor, products in vp.items():
        db_vendor = Vendor(name=vendor, products=[])
        session.add(db_vendor)
        for product in list(set(products)):
            db_product = Product(name=product, vendor=db_vendor)
            session.add(db_product)
        session.commit()


if __name__ == '__main__':
    Base.metadata.create_all(engine)
    session = Session(engine)

    fill_db(session)

    print("FIN.")
