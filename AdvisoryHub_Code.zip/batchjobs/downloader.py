import json
import os
import re
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse

import dateutil.parser
import requests
import sqlalchemy.exc
from sqlalchemy.orm import Session

from batchjobs.batchbase import BatchBase
from datamodel.task import TaskDetail
from extraction.construction import DokumentGenerator
from extraction.mainextraction import Extractor
from helper.task import get_random_tasks, get_random_fresh_tasks
from preview import document_obj_from_csaf


class Downloader(BatchBase):
    def __init__(self, engine: sqlalchemy.engine, interval: timedelta, strategy: str = "fresh"):
        super(Downloader, self).__init__(interval)
        self.storage_path = "resources/download-details/"
        self.engine = engine
        self.session = Session(engine)
        self.meta_session = Session(create_engine("sqlite:///resources/csaf.db", echo=False))
        self.strategy = strategy
        assert strategy in ["random", "fresh", "recrawl"]

    def action(self):
        """Query detail tasks from DB and execute them if they are eligible for retrieval."""
        tasks = self.get_tasks()
        for task in tasks:
            recrawl = self.recrawl_eligible(task)
            if recrawl:
                self.perform_task(task)
        print("Down working queue, waiting")

    def get_tasks(self) -> [TaskDetail]:
        """Return a list of tasks from the database. Which tasks are returned depends on the selection strategy."""

        if self.strategy == "random":
            return get_random_tasks(self.session, 10)
        if self.strategy == "fresh":
            return get_random_fresh_tasks(self.session, 10)
        return []

    @staticmethod
    def recrawl_eligible(task: TaskDetail) -> bool:
        """Check if task should be retrieved based on age and time of the last retrieval."""

        # Always retrieve advisories that have not been retrieved yet
        if task.lastretrieved == "" or task.lastretrieved is None:
            return True

        # Tasks that were updated after the last retrieval are always eligible for retrival
        if task.updated:
            if task.updated > task.lastretrieved:
                return True

        # Find out how old a task is (in days) and store it in age.days.
        if task.published:
            date1 = dateutil.parser.parse(task.published).replace(tzinfo=None)
        else:
            date1 = dateutil.parser.parse(task.firstseen).replace(tzinfo=None)
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        age = now - date1

        lastretrieved = dateutil.parser.parse(task.lastretrieved).replace(tzinfo=None)

        # Retrieve advisories that are younger than 7 days every 6 hours
        if age.days < 7:
            if lastretrieved + timedelta(hours=6) < now:
                return True

        # Retrieve advisories that are between 1 week and 1 month old every 2 days
        if 7 < age.days <= 30:
            if lastretrieved + timedelta(hours=48) < now:
                return True

        # Retrieve advisories that are older than 1 month every 15 days
        if age.days > 30:
            if lastretrieved + timedelta(days=15) < now:
                return True

        return False

    def perform_task(self, task: TaskDetail):
        """Retrieve detail url if possible, process content and task details according to content type."""

        # Set download directory, create it if needed
        netloc = urlparse(task.domain).netloc
        if not os.path.isdir(self.storage_path + netloc):
            os.makedirs(self.storage_path + netloc)

        resp = self.make_request(task) if task.url else None

        csaf_dict = self.handle_response(task, resp)  # This is None, if nothing changed since last retrieval
        if csaf_dict:
            # Write json_file
            filename = self.generate_filename(csaf_dict)
            self.write_json(csaf_dict, netloc, filename)
            # Store object in preview database
            document_obj_from_csaf(filename, csaf_dict, self.meta_session)  # TODO: Create whole path from file

        task.lastretrieved = datetime.now(timezone.utc)

        if resp:
            task.retrievalserverts = resp.headers.get("Date")
            task.retrievaletag = resp.headers.get("ETag")
        print(f"Updating {task.url} in DB")
        self.session.commit()

    def make_request(self, task: TaskDetail) -> requests.Response | None:
        """Make request to task url, send caching header to save bandwidth."""
        headers = {}
        if task.retrievaletag:
            headers["ETag"] = str(task.retrievaletag)
        if task.retrievalserverts:
            headers["If-Modified-Since"] = str(task.retrievalserverts)

        try:
            resp = requests.get(task.url, headers=headers, timeout=5)
        except requests.exceptions.RequestException:
            resp = None

        return resp

    def handle_response(self, task: TaskDetail, response: requests.Response | None) -> {}:
        """
        Check content type of response and call appropriate handler for processing the response.
        Forward response to the caller of the function.
        """

        if not response:
            return self.handle_html_response(task, None)  # Extraction only based on task details

        if response.status_code == 200:
            ct = response.headers.get("content-type")

            if "application/json" in ct:
                if processed_response := self.handle_json_response(response):
                    return processed_response
            elif "application/octet-stream" in ct:
                if processed_response := self.handle_json_response(response):
                    return processed_response
            elif "text/plain" in ct:
                if processed_response := self.handle_json_response(response):
                    return processed_response
            elif "text/html" in ct:
                if processed_response := self.handle_html_response(task, response):
                    return processed_response
            elif "application/pdf" in ct:
                pass  # handled like there is no response at all
            else:
                if processed_response := self.handle_json_response(response):  # Try one last time if content cont. JSON
                    return processed_response

            return self.handle_html_response(task, None)

        elif response.status_code == 304:
            print(response.headers)
            print("Noting changed since last retrieval")

    def handle_html_response(self, task: TaskDetail, response: requests.Response | None) -> {}:
        """Take a task and optionally a response, perform extraction and return CSAF as dict."""
        csaf_dict = {}
        try:
            extractor = Extractor(task, response, self.engine)
            generator = DokumentGenerator(extractor)
            csaf_dict = generator.generate()
        except Exception as e:
            # Do not raise Exception in prod, this is only to catch bugs during development
            raise RuntimeError(f"Extraction failed due to: {e}")
        return csaf_dict

    def handle_json_response(self, response: requests.Response) -> {}:
        """Take a response and return it as a JSON dictionary, return it empty if response did not contain JSON."""
        try:
            csaf_file_dict = response.json()
        except requests.exceptions.JSONDecodeError:
            csaf_file_dict = {}
        return csaf_file_dict

    def write_json(self, csaf_file_dict: {}, netloc: str, filename: str) -> None:
        filepath = f"{self.storage_path}{netloc}/{filename}"
        print(f"Preparing to write file: {filepath}")
        with open(filepath, 'w') as f:
            json.dump(csaf_file_dict, f)

    def generate_filename(self, csaf_dict: {}) -> str:
        identifier = csaf_dict["document"]["tracking"]["id"]
        return re.sub(r"[^+\-a-z0-9]+", "_", identifier.lower()) + ".json"


if __name__ == '__main__':
    from monitoring.retrieverlogging import setup_logger
    from sqlalchemy import create_engine

    logger = setup_logger("CSAF Downloader")
    engine = create_engine("sqlite:///resources/task.db", echo=False)

    d1 = Downloader(engine, interval=timedelta(seconds=1), strategy="random")
    d1.start()
    # d1 = Downloader(engine, interval=timedelta(seconds=45), strategy="fresh")
    # d1.start()
    d1 = Downloader(engine, interval=timedelta(seconds=45), strategy="random")
    d1.start()
