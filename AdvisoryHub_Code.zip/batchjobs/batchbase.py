import threading
import time
from datetime import timedelta


class BatchBase(threading.Thread):
    def __init__(self, interval: timedelta):
        super(BatchBase, self).__init__()
        self.interval = interval

    def run(self):
        while True:
            self.action()
            # TODO: The following code does not account for the pc going into sleep mode -> change to sth. better
            time.sleep(self.interval.seconds)

    def action(self):
        print("Hello")


if __name__ == '__main__':
    test_interval = timedelta(seconds=2)
    b = BatchBase(test_interval)
    b.start()
