from urllib.parse import urlparse

from werkzeug.datastructures import MultiDict

from datamodel.csaf import Document
from datamodel.task import TaskOverview


def documents_to_dicts(advisories: [Document]) -> [{}]:
    # Transform list of advisory_document_db objects into dicts
    advisories_converted = []
    for adv in advisories:

        converted = dict(adv.__dict__)
        extra = {"provider": urlparse(adv.url).netloc,
                 "vulnerabilities": [vul for vul in adv.vulnerabilities],
                 "published": adv.published.replace("T", " ")[0:19],
                 "updated": adv.updated.replace("T", " ")[0:19],
                 "displaymore": "none" if len([vul for vul in adv.vulnerabilities]) <= 3 else "block",
                 "vendors": [ven.name for ven in adv.vendors]
                 }
        adv_new = converted | extra
        advisories_converted.append(adv_new)
    return advisories_converted


def form_to_task(form: MultiDict, mapping="", content_mapping="") -> TaskOverview:
    """Take a html form from received from the client and create a TaskOverview object from it."""
    retrieval_endpoint = form.get("retrieval_endpoint")
    if not retrieval_endpoint:
        retrieval_endpoint = form.get("retrieval_url")

    task = TaskOverview(type=form.get("requesttype"),
                        request_method=form.get("requestmethod"),
                        url=form.get("retrieval_url"),
                        retrieval_endpoint=retrieval_endpoint,
                        selector=form.get("retrieval_selector"),
                        body=form.get("retrieval_body"),
                        header=form.get("retrieval_header"),
                        mapping=mapping,
                        contentmapping=content_mapping,
                        ignorereferences=form.get("template_references"),
                        interval="",
                        lastretrievalattempt="",
                        lastretrieved="")
    return task
