from random import sample

from datamodel.task import TaskDetail


def get_random_tasks(session, n=10) -> [TaskDetail]:
    """Get n random tasks in no particular order."""

    all_tasks = session.query(TaskDetail.url, TaskDetail.identifier).all()
    all_tasks = list(all_tasks)
    if len(all_tasks) <= n:
        return get_tasks_from_db(session, all_tasks)
    choice = sample(all_tasks, n)
    return get_tasks_from_db(session, choice)


def get_tasks_from_db(session, choice: [(str, str)]) -> [TaskDetail]:
    tasks = []
    for url, identifier in choice:
        task = session.query(TaskDetail).where(
            TaskDetail.url == url,
            TaskDetail.identifier == identifier
        ).first()
        if task:
            tasks.append(task)
    return tasks


def get_random_fresh_tasks(session, n=10) -> [TaskDetail]:
    """Get n random tasks that have not been retrieved before in no particular order."""
    all_tasks = session.query(TaskDetail.url, TaskDetail.identifier).where(
        TaskDetail.lastretrieved.is_(None)).all()
    all_tasks = list(all_tasks)
    if len(all_tasks) <= n:
        return get_tasks_from_db(session, all_tasks)
    choice = sample(list(all_tasks), n)
    return get_tasks_from_db(session, choice)
