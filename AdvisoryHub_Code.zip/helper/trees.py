from lxml.etree import _Element


def tree_matching_algorithm(element_a: _Element, element_b: _Element):
    # Source: Identifying Syntactic Differences Between Two Programs (Yang, W.)
    # Source: https://ccc.inaoep.mx/~villasen/bib/spe040wy.pdf
    # TODO: Check if this scheme can also be applied to other properties than "tag" (e.g. css id)

    # Check if the roots have distinct symbols
    if element_a.tag != element_b.tag:
        return 0

    # Get the number of first-level sub-trees of A and B
    m = len(element_a.getchildren())
    n = len(element_b.getchildren())

    # Initialize array with 0
    # TODO: Check if performance can be improved by using numpy
    M = [[0] * (n + 1) for _ in range(m + 1)]

    # Iterate over each pair of sub-trees in A and B

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            # Calculate the matching score between the i-th sub-tree of A and the j-th sub-tree of B
            W = tree_matching_algorithm(element_a.getchildren()[i - 1], element_b.getchildren()[j - 1])

            # Store value in array
            M[i][j] = max(M[i][j - 1], M[i - 1][j], M[i - 1][j - 1] + W)

    return M[m][n] + 1


def tree_similarity(self, url1, url2):
    """Print the similarity between two the trees constructed from two urls."""
    response1 = requests.get(url1)
    html_parser1 = etree.HTMLParser()
    root1 = etree.fromstring(response1.text, parser=html_parser1)
    response2 = requests.get(url2)
    html_parser2 = etree.HTMLParser()
    root2 = etree.fromstring(response2.text, parser=html_parser2)
    match_count = tree_matching_algorithm(root1, root2)

    length1 = len(list(root1.iter()))
    length2 = len(list(root2.iter()))
    print(f"Length of tree1: {length1}")
    print(f"Length of tree2: {length2}")
    print(f"Match count {match_count}")
    print(f"Similarity: {match_count / length1}")
