import re

import nltk


def lookup_field(session, v_str, objtype):
    r = []  # result_list
    r += session.query(objtype).where(objtype.name == v_str).all()  # directly
    r += session.query(objtype).where(objtype.name == re.sub("[^0-9a-zA-Z]+", '*', v_str)).all()  # remove non-alpha
    r += session.query(objtype).where(objtype.name == v_str.replace(" ", "")).all()  # remove space
    r += session.query(objtype).where(objtype.name == v_str.replace("-", "")).all()  # remove hyphen
    r += session.query(objtype).where(objtype.name == v_str.replace(" ", "_")).all()  # replace space with underscore
    r += session.query(objtype).where(objtype.name == v_str.replace(" ", "-")).all()  # replace space with hyphen
    r = list(set(r))
    return r


def generate_n_grams(input_str: str, n: int = 3) -> [str]:
    """Generate a list of n-grams up to length n."""
    token_lst = input_str.replace(".", "").lower().split(" ")

    result = []

    for i in range(1, n + 1):
        ngrams = list(nltk.ngrams(token_lst, i))
        for gram in ngrams:
            gram_str = "_".join(gram).strip()
            result.append(gram_str)

    return result


def prepare_for_db_lookup(s: str) -> [str]:
    s_prepared = s.lower().split()
    return s_prepared
