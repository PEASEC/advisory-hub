import requests
import json


def get_token():
    url = "https://support.hpe.com/connect/s/sfsites/aura?r=0&CoveoV2.ContentHandler.getLoader=1&other.DCEHPESearchControllerSB.getToken=1"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": "https://support.hpe.com/connect/s/securitybulletinlibrary?language=en_US",
        "X-SFDC-Page-Scope-Id": "8d2219da-d582-40d4-9874-c5de6848746e",
        "X-SFDC-Request-Id": "2575000000cd16ea26",
        "X-SFDC-Page-Cache": "44903ef783285dfd",
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "Origin": "https://support.hpe.com",
        "Connection": "keep-alive",
        "Cookie": r"hpeuck_prefs=1111; sa_session_id=Zd47tqA3T3HZ4Bh^@IZqezQAAAAM; "
                  r"sa_user_tracking_id=Zd47tqA3T3HZ4Bh^@IZqezQAAAAM; "
                  r"DWF-PROXY-SESSION-ID=5DB9A197247AEBE5BBA6EA6D0F94E0C8.tomcat6-p1lg505357; "
                  r"HP_SPF_LOCALE=en-US; "
                  r"sfdc-stream=^!D1V36l/9NGhyHYnnP1n3kd6EN9chLEsu3O9mHJ5pNA/hkhAevLYmp8/Vpptjgb2vpNMnR1OyrX0WYC0=; "
                  r"LSKey-c\$CookieConsentPolicy=0:1; "
                  r"CookieConsentPolicy=0:1; "
                  r"dce.auth.source=IAM; "
                  r"BIGipServerportal-iam-ext-pro_POOL_443=661411338.47873.0000; "
                  r"AKA_A2=A; _dd_s=; TAsessionID=751d8389-1c51-4395-9d1a-a66d8c4c48c2^|NEW; "
                  r"notice_behavior=implied,us; "
                  r"LSKey-c\$DCE_NOTIFICATIONS=^[{""id"":""hpscMotd.hpe_Welcome"",""messageState"":""NEW"",""usersStates"":{},""publishedDate"":""Apr 17, 2023 4:39:24 AM""},{""id"":""TechTipvideosAlert"",""messageState"":""NEW"",""usersStates"":{},""publishedDate"":""Nov 22, 2023 3:34:50 AM""},{""id"":""VA_Parts_Order_Note"",""messageState"":""NEW"",""usersStates"":{},""publishedDate"":""Feb 20, 2024 4:40:08 PM""}^]; "
                  r"AMCV_56B5A25055667EED7F000101^%^40AdobeOrg=-1124106680^%^7CMCIDTS^%^7C19781^%^7CMCMID^%^7C57381925095434749871229810239765351309^%^7CMCAID^%^7CNONE^%^7CMCOPTOUT-1709070305s^%^7CNONE^%^7CvVersion^%^7C5.2.0; "
                  r"AMCVS_56B5A25055667EED7F000101^%^40AdobeOrg=1; "
                  r"pctrk=ccbf9c5c-067d-41b3-87e5-f369e37b918a; "
                  r"LSKey-c\$CookieConsentPolicy=; CookieConsentPolicy=; _dd_s=",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "no-cors",
        "Sec-Fetch-Site": "same-origin",
        "TE": "trailers",
        "Pragma": "no-cache",
        "Cache-Control": "no-cache"
    }
    message = "message=%7B%22actions%22%3A%5B%7B%22id%22%3A%2285%3Ba%22%2C%22descriptor%22%3A%22apex%3A%2F%2FDCEHPESearchControllerSB%2FACTION%24getToken%22%2C%22callingDescriptor%22%3A%22markup%3A%2F%2Fc%3AdceCoveoSearchCustomEndpointHandlerSB%22%2C%22params%22%3A%7B%7D%7D%2C%7B%22id%22%3A%2287%3Ba%22%2C%22descriptor%22%3A%22apex%3A%2F%2FCoveoV2.ContentHandlerController%2FACTION%24getLoader%22%2C%22callingDescriptor%22%3A%22markup%3A%2F%2FCoveoV2%3AContentHandler%22%2C%22params%22%3A%7B%22loaderParams%22%3A%7B%22name%22%3A%22dceHPESecurityBulletinLibrary%22%7D%2C%22componentType%22%3A%22search%22%7D%7D%5D%7D&aura.context=%7B%22mode%22%3A%22PROD%22%2C%22fwuid%22%3A%22MFZGMnNxcWxxQVZkaERsVUY3RzNmZ0ZLaHg4ZmdiaWU2OUVpTFc3bFZBOVEyNDguMTAuMy01LjAuOQ%22%2C%22app%22%3A%22siteforce%3AcommunityApp%22%2C%22loaded%22%3A%7B%22APPLICATION%40markup%3A%2F%2Fsiteforce%3AcommunityApp%22%3A%22pbTYxUpp_9IPfsISARS1_Q%22%2C%22COMPONENT%40markup%3A%2F%2Finstrumentation%3Ao11ySecondaryLoader%22%3A%22VZ2Rg7MN_BaoV_0Qlk5pAw%22%7D%2C%22dn%22%3A%5B%5D%2C%22globals%22%3A%7B%7D%2C%22uad%22%3Afalse%7D&aura.pageURI=%2Fconnect%2Fs%2Fsecuritybulletinlibrary%3Flanguage%3Den_US&aura.token=null"
    # token = "eyJhbGciOiJIUzI1NiJ9.eyJ1c2VyR3JvdXBzIjpbIkhQRSBTdXBwb3J0IENlbnRlciBQcm9maWxlIl0sInNlYXJjaEh1YiI6IkhQRS1TZWN1cml0eUJ1bGxldGlucy1QYWdlIiwidjgiOnRydWUsInRva2VuSWQiOiJyejJpaGh4YWh4am5ra2YybnEyMzJpMm5yYSIsIm9yZ2FuaXphdGlvbiI6Imhld2xldHRwYWNrYXJkcHJvZHVjdGlvbml3bWc5Yjl3IiwidXNlcklkcyI6W3sidHlwZSI6IlVzZXIiLCJuYW1lIjoiYW5vbnltb3VzIiwicHJvdmlkZXIiOiJFbWFpbCBTZWN1cml0eSBQcm92aWRlciJ9LHsidHlwZSI6IlVzZXIiLCJuYW1lIjoiYW5vbnltb3VzQGNvdmVvLmNvbSIsInByb3ZpZGVyIjoiRW1haWwgU2VjdXJpdHkgUHJvdmlkZXIifV0sInJvbGVzIjpbInF1ZXJ5RXhlY3V0b3IiXSwiaXNzIjoiU2VhcmNoQXBpIiwiZXhwIjoxNzA5MTQ3MTY0LCJpYXQiOjE3MDkwNjA3NjR9.1JDLHaIAW1AJ4YjzcwjgUTtmU0-GPR4IBejusy0HNCU"
    resp = requests.post(url, data=message, headers=headers)
    obj = json.loads(resp.content)
    token_dict_str = obj["actions"][0]["returnValue"]
    token_dict = json.loads(token_dict_str)
    token = token_dict["token"]
    return token
