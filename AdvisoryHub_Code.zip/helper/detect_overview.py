from seleniumwire import webdriver
from time import sleep
from seleniumwire.utils import decode
from urllib.parse import urlparse

# SELENIUM TEST
# THIS FILE IS CURRENTLY NOT PART OF THE PROJECT


browser = webdriver.Firefox()
browser.get('https://helpx.adobe.com/security.html')
needle = "APSB24-03"

sleep(5)

relevant_requests = []
for request in browser.requests:

    irrelevant_content_types = ["text/css", "text/javascript", "image/svg+xml"]
    irrelevant_domains = ["firefox.settings.services.mozilla.com", "detectportal.firefox.com",
                          "content-signature-2.cdn.mozilla.net", "shavar.services.mozilla.com",
                          "tracking-protection.cdn.mozilla.net"]

    try:
        content_type = request.response.request_headers['Content-Type']
        url_p = urlparse(request.url)
        if content_type not in irrelevant_content_types and url_p.hostname not in irrelevant_domains:
            body = decode(request.response.body, request.response.request_headers.get('Content-Encoding', 'identity'))
            if request.response:
                print(
                    request.url,
                    request.response.status_code,
                )
                if needle in str(body):
                    print("Needle found")
    except AttributeError:
        pass
browser.close()
