import pandas as pd
from lxml import etree
from lxml.etree import ElementTree


def clean_tree(tree: ElementTree):
    """Remove unwanted html elements from DOM (inplace)."""
    tags_to_remove = ["head", "footer", "nav", "aside", "svg", "path", "script", "style"]
    for tag in tags_to_remove:
        for elem in tree.findall('.//' + tag):
            # print(f"Removing tag {elem.tag}")
            elem.getparent().remove(elem)


def extract_tables(tree: ElementTree) -> [(None, pd.DataFrame)]:
    """
    Extract tables from tree and put them in a list. The empty table shell is kept in the tree to mark the position,
    so that we later know which position the table was extracted from. Operation is inplace.
    """
    tag = "table"
    extracted_tables = []

    if not tree:
        return []

    for element in tree.findall('.//' + tag):
        element_str = etree.tostring(element, pretty_print=True)
        tables = pd.read_html(element_str)
        tables = [(None, tab) for tab in tables]
        extracted_tables += tables
        for child in element.getchildren():
            element.remove(child)
    return extracted_tables


def tree_to_records(tree: ElementTree):  # , tables: list) -> [dict]:
    """
    Take a tree and return a list of records. The records are of dict type and contain a document id,
    """
    table_counter = 0
    buffer = " "  # Accumulate the extracted text temporarily
    stack = [None, None, None]
    records = []

    for element in tree.iter():
        text = element.text.strip() if element.text else ""
        if element.tag in ("h1", "h2", "h3"):
            level = int(element.tag[1:]) - 1  # Can be 0 - 2 (representing a stack pointer)

            record = {"h1": stack[0], "h2": stack[1], "h3": stack[2], "content": buffer}
            records.append(record)
            buffer = ""  # Reset buffer
            stack[level] = text

            # New h tags of higher priority (e.g. h1) reset h2 and h3 tags to None
            if level == 0:
                stack[1], stack[2] = None, None
            if level == 1:
                stack[2] = None

        # Create new record with _table postfix as key and table as content
        elif element.tag == "table":
            element_str = etree.tostring(element, pretty_print=True)
            table = pd.read_html(element_str)[0]
            record = {"h1": str(stack[0]) + "_table", "h2": str(stack[1]) + "_table", "h3": str(stack[2]) + "_table",
                      "content": table}
            records.append(record)

        else:
            buffer += " " + text

    return records
