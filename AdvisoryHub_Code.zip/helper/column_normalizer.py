from collections import defaultdict
from datetime import datetime

import datefinder
import dateutil.parser

# TODO: This code definitely needs to be simplified

title = "xx_title"
identifier = "xx_identifier"
products = "xx_products"
published = "xx_published"
updated = "xx_updated"
cve = "xx_cve"
score = "xx_score"
severity = "xx_severity"
content = "xx_content"
summary = "xx_summary"
url = "xx_url"
vendor = "xx_vendor"
advisory_type = "xx_type"
version = "xx_version"

mapping = {
    "url": url,
    "link": url,
    "name": title,
    "advisories": title,
    "vulnerability": title,
    "title": title,
    "advisory (pdf)": title,
    "cvetitle": title,
    "alltitle": title,
    "articletitle": title,
    "report id": identifier,
    "zdi id": identifier,
    "advisory id": identifier,
    "security advisory id": identifier,
    "advisory-nummer": identifier,
    "id": identifier,
    "identifier": identifier,
    "advisory number": identifier,
    "bulletin_id": identifier,
    "bulletin id": identifier,
    "documentid": identifier,
    "kbarticleid": identifier,
    "issue identifier": identifier,
    "issue platform": products,
    "products": products,
    "affects": products,
    "affected vendor(s):": products,
    "affected products": products,
    "portal_product_names": products,
    "field_product": products,
    "supportproducts": products,
    "cve_list": cve,
    "cvenumber": cve,
    "cve number": cve,
    "cvss score*": cve,
    "cve": cve,
    "assigned cve ids": cve,
    "cve identifier(s)": cve,
    "field_cve_id": cve,
    "affectedcve": cve,
    "cvss": score,
    "cvss score": score,
    "cvss v3.0": score,
    "basescore": score,
    "date": published,
    "field_pub_date": published,
    "report date": published,
    "published": published,
    "release date": published,
    "originally posted": published,
    "publication date": published,
    "publication_date": published,
    "pubDate": published,
    "releasedate": published,
    "publish date": published,
    "posted_on": published,
    "firstpublished": published,
    "updated": updated,
    "last_update_date": updated,
    "letzte änderung": updated,
    "last update": updated,
    "last_update": updated,
    "last updated": updated,
    "lastpublished": updated,
    "latestrevisiondate": updated,
    "severity": severity,
    "summary": summary,
    "vendor": vendor,
    "type": advisory_type,
    "version": version,
    "description": content
}

normalizer = defaultdict(lambda: "other", mapping)

column_types = list(set([v for k, v in mapping.items()])) + ["other"]  # list of all possible column types


def process_line(line: dict) -> dict:
    """
    Take one line from the result coming from the Retriever, search for well-known attributes and promote them to
    values to be inserted into their respective database columns. Keep the other attributes in the catch all dict.
    """
    column_attributes = {"url": "", "title": "", "identifier": "", "products": "", "published": "",
                         "updated": "", "cve": "", "score": "", "vendor": "", "severity": "",
                         "summary": "", "type": "", "retrievalserverts": "", "retrievaletag": "", "content": ""}

    # Well-known attribute types can be identified by their xx_prefix
    for k in column_attributes.keys():
        # Parse time column
        if f"xx_{k}" in line.keys():
            if f"xx_{k}" == f"xx_published" or f"xx_{k}" == f"xx_updated":
                col_str = str(line.pop(f"xx_{k}"))
                column_attributes[k] = parse_time_str(col_str)
            else:
                # Parse non-time column
                column_attributes[k] = str(line.pop(f"xx_{k}"))

    return column_attributes


def parse_time_str(time_str: str) -> datetime | str:
    """Try to parse string to datetime object, return empty sting otherwise."""
    try:
        time_parsed = dateutil.parser.parse(time_str)
    except dateutil.parser._parser.ParserError:
        matches = list(datefinder.find_dates(time_str))
        if matches:
            time_parsed = matches[0]
        else:
            time_parsed = ""
    return time_parsed
