import pandas as pd
from io import StringIO

from bs4 import BeautifulSoup
import ast

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)


def read_from_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = df.columns.to_series().apply(ast.literal_eval)
    df = df.map(ast.literal_eval)  # TODO: Make sure that only the outermost tuple layer is evaled (no nested tuples)
    return df


def soup2df(soup: BeautifulSoup) -> list:
    """Transform a BeautifulSoup object into a Pandas DataFrame while maintaining urls as extra columns"""
    tables = pd.read_html(StringIO(str(soup)), extract_links="all")
    return []

'''
def promote_headers(df: pd.DataFrame) -> pd.DataFrame:
    """If column headers are int typed, promote first row of data to headers."""
    if all([isinstance(col, tuple) for col in df.columns.tolist()]):
        # All headers are already of tuple type
        return df
    df.columns = df.iloc[0]
    df = df[1:]  # remove first row if column headers are int based
    return df


def flatten_link_df(df: pd.DataFrame) -> pd.DataFrame:
    """Transform a Dataframe containing tuples (content, link) into a Dataframe where links are in extra columns."""
    import itertools

    # df of all types as nested list
    all_types = df.map(lambda x: isinstance(x, tuple)).values.tolist()
    all_types_flat = list(itertools.chain(*all_types))
    if False in set(all_types_flat):
        # df is not all tuples
        return df

    new_df = pd.DataFrame()

    for num, colum in enumerate(df.columns):
        try:
            proper_column_name = colum[0]
        except TypeError:
            proper_column_name = colum

        try:
            new_df[[proper_column_name, proper_column_name + " Link"]] = pd.DataFrame(df.iloc[:, num].tolist(),
                                                                                      index=df.index)
        except Exception as e:
            # Return empty df in case of error
            return pd.DataFrame()

    new_df.dropna(how='all', axis=1, inplace=True)

    return new_df


def combine_urls(url, path):
    """Take an url (host) and a path and combine them into an absolute url."""

    if path is None:
        return None

    if path.startswith('https:') or path.startswith('http:'):
        return path

    url_p = urlparse(url)
    combined = url_p.scheme + "://" + url_p.netloc + ("/" + path).replace("//", "/")
    return combined


def make_links_absolute(url, df: pd.DataFrame) -> pd.DataFrame:
    """Take a url and a dataframe and make all relative links absolute."""
    # TODO: Take multiple edge cases in account (vuln pages not under root, but shared folder)
    # TODO: What about links in json tables?
    # TODO: Detect absolute tables / relative tables
    # TODO: Select best url to be the url that is stored in the databse

    for num, col in enumerate(df.columns):

        # Only search in columns that end with "Link" (this column is set by the htmlstatic retriever)
        if col.endswith('Link'):
            column_entries = df[col].tolist()
            column_entries_str = [entry for entry in column_entries if isinstance(entry, str)]

            # Make 1 request to first assembled url to test if it worked
            test = combine_urls(url, column_entries_str[0])
            request_worked = False

            try:
                req = requests.get(test)
                a = f"Request yielded statuscode {req.status_code}"
                request_worked = True
            except Exception as e:
                a = e
            if request_worked and req.status_code not in [404, 500]:
                print(f"Testrequest to: {test} worked")
                df[col] = df[col].map(lambda x: combine_urls(url, x))
            else:
                print(f"Testrequest to: {test} failed due to: {a}")

    return df


def is_abs_url(x):
    """Check if str is url, return url if it is an url, None otherwise."""
    if isinstance(x, str) and x.startswith("http"):
        return True
    else:
        return False


def is_rel_url(x):
    """Check if str is a relative url, return url if it is an url, None otherwise."""
    if isinstance(x, str):
        if x.startswith("/"):
            return True
        if " " in x.strip():
            return False
    else:
        return False


def find_abs_url_column(df: pd.DataFrame) -> list:
    """
    Take a dataframe representing an overview page and find the column that most likely contains the links to the detail
    pages
    """
    abs_url_columns = []
    for num, col in enumerate(df.columns):
        print(f"Iterating over column {col}")
        if all(df[col].map(lambda x: is_abs_url(x))):
            abs_url_columns.append(col)
    return abs_url_columns


def find_rel_url_column(df: pd.DataFrame) -> list:
    new_df = pd.DataFrame()
    for num, col in enumerate(df.columns):
        print(f"Iterating over column {col}")
        df[col] = df[col].map(lambda x: is_rel_url(x))
    return new_df


def simplify_urls(df: pd.DataFrame):
    """
    Take a df containing multiple columns with different or identical urls.
    Select the column that is most likely pointing to the detail page of the vulnerabilities.
    Function works inplace.
    """
    # Check all columns containing urls and eliminate identical columns
    url_columns = find_abs_url_column(df)
    for col1 in url_columns:
        for col2 in url_columns:
            if col1 != col2:
                # Make sure that columns to compare were not already deleted
                if col1 in df.columns and col2 in df.columns:
                    # Compare columns and delete them form df if their content is identical
                    if df[col1].equals(df[col2]):
                        df.drop(col2, axis=1, inplace=True)

    url_columns = find_abs_url_column(df)

    if len(url_columns) == 0:
        # This should not happen
        pass
        return
    if len(url_columns) == 1:
        # Rename column
        df.rename(columns={url_columns[0]: 'url'}, inplace=True)
        return
    else:
        # TODO: Test this section
        # Select url column with most distinct values
        unique_values = {col: df[col].nunique() for col in url_columns}
        col_with_max_nunique = max(unique_values, key=unique_values.get)
        df.rename(columns={col_with_max_nunique: 'url'}, inplace=True)

'''

if __name__ == '__main__':
    from monitoring.connectors.ajax import AjaxRetriever

    # s = StaticRetriever("https://www.talosintelligence.com/vulnerability_reports/", request_method="GET",
    #                    retrieval_endpoint="https://www.talosintelligence.com/vulnerability_reports/")
    s = AjaxRetriever(request_method="GET",
                      url="https://sec.cloudapps.cisco.com/security/center/publicationService.x?criteria=exact&cves=&keyword=&last_published_date=&limit=20&offset=0&publicationTypeIDs=1,3&securityImpactRatings=&sort=-day_sir&title=",
                      retrieval_endpoint="https://sec.cloudapps.cisco.com/security/center/publicationService.x?criteria=exact&cves=&keyword=&last_published_date=&limit=20&offset=0&publicationTypeIDs=1,3&securityImpactRatings=&sort=-day_sir&title=")
    df = s.retrieve()
    print(df)
    df = make_links_absolute(s.url, df)
    simplify_urls(df)
    print(df)

    # df3[['c1', 'c2']] = pd.DataFrame(df3.iloc[:, 1].tolist(), index=df.index)
    # print(new_df)
    # print(df.columns)
    # print(df)
