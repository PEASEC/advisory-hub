import pandas as pd
from difflib import SequenceMatcher
import re
import dateutil.parser


def distance(x1, x2):
    dist = SequenceMatcher(None, x1, x2).ratio()
    return dist


def detect_date(text):
    try:
        parsed = dateutil.parser.parse(text)
        is_date = True
    except Exception as e:
        is_date = False
    return is_date


def detect_cve(text):
    regex = r"CVE-\d{4}-\d{4,7}"
    return bool(re.search(regex, text))


def detect_url(text):
    return bool(re.search("^http", str(text).strip()))


def calculate_score_binary(df):
    result = {}
    row_count = df.shape[0]
    for col in df.columns:
        true_number = df[col].value_counts().to_dict().get(True)
        if true_number is None:
            result[col] = 0
        else:
            result[col] = true_number / row_count
    return result


def calculate_score_float(df):
    result = {}
    row_count = df.shape[0]
    for col in df.columns:
        result[col] = df[col].mean()
    return result


def detect_table_scheme(url, df: pd.DataFrame) -> list:
    print(df)
    # Detect URLs
    result = calculate_score_binary(df.map(lambda x: detect_url(x)))
    print(result)

    # Detect Advisory Page URLs
    # (cell url has common start with overview page url)
    result = calculate_score_float(df.map(lambda x: distance(url, str(x))))
    print(result)

    # Detect dates
    result = calculate_score_binary(df.map(lambda x: detect_date(x)))
    print(result)

    # Detect CVE
    result = calculate_score_binary(df.map(lambda x: detect_cve(str(x))))
    print(result)

    # Detect ID

    # Detect Title
    # - Long text, but does not contain lots of full stops (.)

    # print(df_out2)


if __name__ == '__main__':
    url = "https://linux.oracle.com/ords/f?p=105:21"
    df = pd.read_csv(f"C:/Users/User1/PycharmProjects/thesistest/downloads/www.zerodayinitiative.com.csv")

    detect_table_scheme(url, df)
