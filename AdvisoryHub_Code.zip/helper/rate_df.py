import pandas as pd


def rate_df(df: pd.DataFrame) -> int:
    """Rate a dataframe based on its likelihood of containing a vulnerability table. The higher the score the likelier
    that it contains links to vulnerability detail pages."""
    score = 0
    rows, columns = df.shape
    if rows >= 2:
        score += 1
    if rows >= 10:
        score += 1
    if columns <= 10:
        score += 1
    if len(set([type(x) for x in df.columns.tolist()])):
        score += 1
    if any([pd.isna(x) for x in df.columns.tolist()]):
        score -= 1
    column_names = ['type', 'severity', 'advisory', 'advisory link', 'summary', 'release date',
                    'report id', 'report id link', 'title', 'title link', 'report date', 'report date link',
                    'cve number', 'cve number link', 'cvss score', 'cvss score link', 'software vendor',
                    'security advisory id', 'publication date', 'affected bosch products', 'reference', 'affected',
                    'description']
    if any(x.lower() in df.columns.tolist() for x in column_names):
        score += 2
    return score
