from xml.etree.ElementTree import Element


def dictify_element(element: Element) -> dict:
    """Recursively extract tree elements into a dictionary containing both element attributes and text content."""
    ignore_attributes = ["class"]
    attributes = {f"{element.tag}.{k}": v for k, v in dict(element.attrib).items() if k not in ignore_attributes}
    if element.text:  # Only add to attributes if element has text
        attributes[str(element.tag) + "-text"] = str(element.text).strip()
    children = element.getchildren()
    for child in children:
        child_attributes = dictify_element(child)
        attributes = attributes | child_attributes  # This is more robust, but may not extract all the data
        # attributes = merge_dicts(attributes, child_attributes)  # This extracts all the data, but column alignment may
        # be incorrect
    attributes = {k: v for k, v in attributes.items() if v}
    return attributes


def merge_dicts(dict1: dict, dict2: dict):
    """Merge two dicts, in case there are duplicated, append numbers to keys"""
    new_dict = dict(dict1)
    for key, value in dict2.items():
        if key in new_dict:
            i = 1
            while f"{key}-{i}" in new_dict:
                i += 1
            new_dict[f"{key}-{i}"] = value
        else:
            new_dict[key] = value
    return new_dict


if __name__ == '__main__':
    from lxml import etree

    test = '<div class="row" onclick="/psirt/FG-IR-23-493"> <div class="col-md-3"> <b>FG-IR-23-493 Administrator cookie leakage</b> <br/> <b class="cve">CVE-2023-41677</b> </div> <div class="col-md-3"> <small>An insufficiently protected credentials vulnerability (CWE-522) in FortiOS and FortiProxy may allow an...</small> </div> <div class="col-md-2"> <small class="item"> <span class="item-group"> <b>FortiOS</b> <span class="item-sub"> 7.4.1, 7.4.0, 7.2.6, 7.2.5, 7.2.4 ... </span> </span> <span class="item-group"> <b>FortiProxy</b> <span class="item-sub"> 7.4.1, 7.4.0, 7.2.7, 7.2.6, 7.2.5 ... </span> </span> </small> </div> <div class="col d-none d-lg-block"> <span class="item"><b>Apr 09, 2024</b></span> </div> <div class="col-md-2 d-lg-none"> <span class="item"><b>Apr 09, 2024</b></span> </div> <div class="col d-none d-lg-block text-center"> </div> <div class="col-md-1 d-lg-none"> </div> <div class="col d-none d-lg-block text-center"> <i class="fa fa-exclamation-triangle" style="color:#FF5733;font-size:45px; vertical-align: middle;" aria-hidden="true"></i> <p><b> High</b></p> </div> <div class="col-md-1 d-lg-none"> <b> High Severity</b> </div> </div>'
    element = etree.fromstring(test)
    print(dictify_element(element=element))
