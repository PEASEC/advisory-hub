## Getting Started
1. Install dependencies listed in requirements.txt
2. Make sure that the working directory for all started scripts is always the root folder
3. Start the following scripts:
   1. /interface/main.py as Flask APP (the interface)
   2. /monitoring/monitoringoverview.py (Monitoring Overview Pages)
   3. /batchjobs/downloader.py (Monitoring Detail Pages)
   4. /batchjobs/referencediscovery.py (Generating Recommendations)
4. Open http://127.0.0.1:5000
5. Create new detail task
6. Retrieval starts automatically