// Source: Yan Holtz via https://github.com/holtzy/D3-graph-gallery (MIT License)

// set the dimensions and margins of the graph
var margin = {top: 20, right: 30, bottom: 40, left: 190},
    width = window.screen.width * 0.8 - margin.left - margin.right,
    height = window.screen.height * 0.8 - margin.top - margin.bottom;

// append the svg object to the body of the page
var svg = d3.select("#my_dataviz")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform",
        "translate(" + margin.left + "," + margin.top + ")");

// Parse the Data
d3.csv("static/references_analysis.csv", function (data) {

    // ----------------
    // Create a tooltip
    // ----------------
    var tooltip = d3.select("#my_dataviz")
        .append("div")
        .style("opacity", 0)
        .style("position", "absolute")
        .attr("class", "tooltip")
        .style("background-color", "white")
        .style("border", "solid")
        .style("border-width", "1px")
        .style("border-radius", "5px")
        .style("padding", "10px")

    // Three function that change the tooltip when user hover / move / leave a cell
    var mouseover = function (d) {
        //var subgroupName = d3.select(this.parentNode).datum().key;
        var col1 = d.Example;
        tooltip
            .html("Example: " + col1)
            .style("opacity", 1);
    }
    var click = function (d) {
        var col1 = d.Example;
        window.location.href = col1;
    }
    var mousemove = function (d) {
        tooltip
            .style("left", (d3.mouse(this)[0] + 120) + "px") // It is important to put the +90: other wise the tooltip is exactly where the point is an it creates a weird effect
            .style("top", (d3.mouse(this)[1] + 90) + "px")
    }
    var mouseleave = function (d) {
        tooltip
            .style("opacity", 0)
    }

    // Add X axis
    var x = d3.scaleLinear()
        .domain([0, data[0].Value]) // Base on how many references are there in the table
        .range([0, width]);
    svg.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(x))
        .selectAll("text")
        .attr("transform", "translate(-10,0)rotate(-45)")
        .style("text-anchor", "end");

    // Y axis
    var y = d3.scaleBand()
        .range([0, height])
        .domain(data.map(function (d) {
            return d.Provider;
        }))
        .padding(.1);
    svg.append("g")
        .call(d3.axisLeft(y))

    //Bars
    svg.selectAll("myRect")
        .data(data)
        .enter()
        .append("rect")
        .attr("x", x(0))
        .attr("y", function (d) {
            return y(d.Provider);
        })
        .attr("width", function (d) {
            return x(d.Value);
        })
        .attr("height", y.bandwidth())
        .attr("fill", function (d) {
            return (d.Color);
        })
        .on("mouseover", mouseover)
        .on("mousemove", mousemove)
        .on("mouseleave", mouseleave)
        .on("click", click)


})

