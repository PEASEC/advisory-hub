window.onload = function () {
    var selectElement = document.getElementById('requesttype');
    var retrieval_url = document.getElementById('retrieval_endpoint');
    var retrieval_endpoint = document.getElementById('retrieval_endpoint');
    var retrieval_selector = document.getElementById('retrieval_selector');
    var cheatsheet = document.getElementById('cheatsheet');
    var bufferblock = document.getElementById('bufferblock');
    selectElement.addEventListener('change', function () {
        var selectedOption2 = selectElement.value;
        switch (selectedOption2) {
            case "static":
                retrieval_url.placeholder = "https://www.example.com/security/advisories";
                retrieval_endpoint.disabled = true;
                retrieval_endpoint.placeholder = "";
                retrieval_selector.disabled = false;
                retrieval_selector.placeholder = "";
                bufferblock.className = "col-4 m-2";
                cheatsheet.style.display = "none";
                break;
            case "ajax":
                retrieval_url.placeholder = "https://www.example.com/security/advisories"
                retrieval_endpoint.disabled = false;
                retrieval_endpoint.placeholder = "https://api.example.com/advisories";
                retrieval_selector.disabled = false;
                retrieval_selector.placeholder = "";
                bufferblock.className = "col-4 m-2";
                cheatsheet.style.display = "none";
                break;
            case "csaf feed":
                retrieval_url.placeholder = "https://example.com/.well-known/csaf/white/advisories.json";
                retrieval_endpoint.disabled = false;
                retrieval_selector.disabled = false;
                retrieval_selector.placeholder = "";
                bufferblock.className = "col-4 m-2";
                cheatsheet.style.display = "none";
                break;
            case "rss":
                retrieval_url.placeholder = "https://www.example.com/security/advisories";
                retrieval_endpoint.disabled = false;
                retrieval_endpoint.placeholder = "https://www.example.com/advisories/feeds/rss/";
                retrieval_selector.disabled = true;
                retrieval_selector.placeholder = "";
                bufferblock.className = "col-4 m-2";
                cheatsheet.style.display = "none";
                break;
            case "url":
                retrieval_endpoint.placeholder = "";
                retrieval_endpoint.disabled = true;
                retrieval_selector.disabled = false;
                retrieval_selector.placeholder = "https://www.example.com/security/publications/";
                bufferblock.className = "col-4 m-2";
                cheatsheet.style.display = "none";
                break;
            case "xpath":
                retrieval_endpoint.placeholder = "";
                retrieval_endpoint.disabled = true;
                retrieval_selector.disabled = false;
                retrieval_selector.placeholder = "https://www.example.com/security/publications/";
                bufferblock.className = "col-2 m-2";
                cheatsheet.style.display = "block";
                break;
            default:
                retrieval_endpoint.disabled = true;
                retrieval_selector.disabled = false;
                bufferblock.className = "col-4 m-2";
                cheatsheet.style.display = "none";
        }

    });
};
