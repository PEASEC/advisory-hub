// Source: Yan Holtz via https://github.com/holtzy/D3-graph-gallery (MIT License)

// set the dimensions and margins of the graph
var margin2 = {top: 30, right: 30, bottom: 70, left: 60},
    width = 900 - margin2.left - margin2.right,
    height = 400 - margin2.top - margin2.bottom;

// append the svg object to the body of the page
var svg2 = d3.select("#my_dataviz2")
    .append("svg")
    .attr("width", width + margin2.left + margin2.right)
    .attr("height", height + margin2.top + margin2.bottom)
    .append("g")
    .attr("transform",
        "translate(" + margin2.left + "," + margin2.top + ")");

// Parse the Data
d3.csv("advisorystats",
    function (data) {

        // For scaling the bars
        const maxAdvisories = data.reduce((max, obj) => {
            return parseInt(obj.Value) > max ? parseInt(obj.Value) : max;
        }, parseInt(data[0].Value));


        // X axis
        var x = d3.scaleBand()
            .range([0, width])
            .domain(data.map(function (d) {
                return d.Date;
            }))
            .padding(0.2);
        svg2.append("g")
            .attr("transform", "translate(0," + height + ")")
            .call(d3.axisBottom(x))
            .selectAll("text")
            .attr("transform", "translate(-10,0)rotate(-45)")
            .style("text-anchor", "end");

        // Add Y axis
        var y = d3.scaleLinear()
            .domain([0, maxAdvisories])
            .range([height, 0]);
        svg2.append("g")
            .call(d3.axisLeft(y));

        // Bars
        svg2.selectAll("mybar")
            .data(data)
            .enter()
            .append("rect")
            .attr("x", function (d) {
                return x(d.Date);
            })
            .attr("y", function (d) {
                return y(d.Value);
            })
            .attr("width", x.bandwidth())
            .attr("height", function (d) {
                return height - y(d.Value);
            })
            .attr("fill", "#69b3a2")

    })