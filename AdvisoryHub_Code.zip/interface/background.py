import threading
import dateutil.parser
from datetime import datetime, timezone, timedelta
import time
from datamodel.task import TaskOverview


class BackgroundWorker(threading.Thread):
    def __init__(self, db_session):
        super(BackgroundWorker, self).__init__()
        self.daemon = True
        self.db_session = db_session

    def run(self):
        while True:
            tasks = self.db_session.query(TaskOverview)
            for task in tasks:
                recrawl = False
                if task.lastretrieved == "" or task.lastretrieved is None:
                    recrawl = True
                else:
                    timestamp_dt = dateutil.parser.parse(task.lastretrieved)
                    current_dt = datetime.now(timezone.utc)
                    if timestamp_dt + timedelta(minutes=30) < current_dt:
                        recrawl = True
                print(f"{task} - {recrawl}")
                time.sleep(10)
