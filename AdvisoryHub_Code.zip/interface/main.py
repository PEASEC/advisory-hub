import csv
import io
import json
from datetime import datetime, timezone, timedelta

import pandas as pd
from flask import Flask, render_template, request, flash, redirect, url_for, Response, make_response
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.sql import text, and_

from datamodel.csaf import Document, Vulnerability, Vendor, Base as CsafBase
from datamodel.task import TaskOverview, TaskDetail, process_import, Base as TaskBase, TaskOverviewDisplayWrapper
from extraction.legacy.extraction_funcs import load_pages
from extraction.legacy.wrapper import WrapperGenerator
from helper.column_normalizer import column_types, process_line
from helper.interface import documents_to_dicts, form_to_task
from monitoring.connectors.factory import get_retriever
from monitoring.retrieverlogging import setup_logger

app = Flask(__name__)
app.secret_key = "change me"
engine_task = create_engine("sqlite:///resources/task.db", echo=False)
engine_csaf = create_engine("sqlite:///resources/csaf.db", echo=False)

session_task = Session(engine_task)
session_csaf = Session(engine_csaf)

# Make sure the databases exist.
TaskBase.metadata.create_all(engine_task)
CsafBase.metadata.create_all(engine_csaf)


def allowed_file(filename: str) -> bool:
    ALLOWED_EXTENSIONS = ["csv"]
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/")
def main():
    twohoursago = datetime.now(timezone.utc) - timedelta(hours=2)
    onedayago = datetime.now(timezone.utc) - timedelta(hours=24)
    dd = {}  # Data dict
    dd["taskoverview_cnt"] = session_task.query(TaskOverview).count()
    dd["taskoverview_healthy_cnt"] = session_task.query(TaskOverview).where(
        TaskOverview.lastretrieved >= twohoursago).count()
    dd["taskdetail_cnt"] = session_task.query(TaskDetail).count()
    dd["taskdetail_new_cnt"] = session_task.query(TaskDetail).where(TaskDetail.firstseen >= onedayago).count()
    return render_template('main.html', dd=dd)


@app.route("/overviewtasks", methods=["GET"])
def overviewtasks():
    tasks = list(session_task.query(TaskOverview))
    tasks_wrapped = [TaskOverviewDisplayWrapper(task) for task in tasks]
    return render_template("tasktable.html", db_entries=tasks_wrapped)


@app.route("/overviewtasks", methods=["POST"])
def overviewtaskimport():
    print(request.files)
    if "file" not in request.files:
        flash("No file uploaded.")
    file = request.files["file"]
    if file.filename == "":
        flash("No file selected.")
    if file and allowed_file(file.filename):
        no_imports = process_import(engine_task, file)
        flash(f"Added {no_imports} entry to database.")
    else:
        flash("Uploaded file is not csv.")
    return redirect(request.url)


@app.route("/addtask", methods=["GET"])
def addtask_get():
    return render_template("addtask_get.html")


@app.route("/addtask", methods=["POST"])
def addtask_post():
    # Make test retrieval request to overview page
    # Allow user to perform column mapping

    task = form_to_task(request.form, mapping="", content_mapping="")
    l1 = setup_logger("test123")

    r1 = get_retriever(task, l1, engine=None)

    try:
        df1 = r1.retrieve()
    except Exception as e:
        import traceback
        flash(str(traceback.format_exc()), "error")
        return redirect(url_for("addtask_post"))

    automapping = r1.determine_column_content(df1)  # Contains mapping/dict: (orig. col. name: detected column name)

    return render_template("addtask_post.html", df=df1, column_types=column_types,
                           request_form_prev=request.form, automapping=automapping)


@app.route("/addtask2", methods=["POST"])
def addtask2_post():
    """Retrieve url, extract example urls, create wrapper, offer user to map wrapper fields to content types."""
    skip_cm = request.args.get("skipcm")  # skip content mapping for quicker response time

    # Extract column mapping by popping attributes beginning with yy_
    column_mapping = {k[3:]: v for k, v in request.form.items() if k.startswith("yy_") and k != "other"}

    task = form_to_task(request.form, mapping=json.dumps(column_mapping), content_mapping="")
    l1 = setup_logger("addtask2")
    r1 = get_retriever(task, l1, None)
    overview_df = r1.retrieve()
    output_records = r1.df_to_detail_tasks(overview_df, column_mapping=column_mapping)
    output_tasks = []

    for line in output_records:
        # Promote well-known attribute types to columns
        first_seen = str(datetime.now(timezone.utc))
        column_attributes = process_line(line)
        ot = TaskDetail(**column_attributes, firstseen=first_seen, lastretrieved=None,
                        domain=task.url, properties=str(line))
        if ot.url and "http" in ot.url:
            output_tasks.append(ot)

    if skip_cm:
        task = form_to_task(request.form, mapping=json.dumps(column_mapping), content_mapping="")
        session_task.add(task)
        session_task.commit()
        flash("Overview Task Added", "success")
        return redirect(url_for("overviewtasks"))

    example_urls = [td.url for td in output_tasks][0:7]  # Construct the wrapper from 8 examples
    if example_urls:
        trees = load_pages(url_list=example_urls)
        wg = WrapperGenerator(trees)
        template_references = wg.get_template_refs()
        wg.preprocess_trees()
        wg.populate_df()
        try:
            # This may fail e.g. in case the extracted links point to PDF files.
            wg.isolate_dynamic_headers()
            df = wg.transpose()
        except Exception as e:
            df = pd.DataFrame()
    else:  # If result does not contain any detail page links to retrieve
        df = pd.DataFrame()
        template_references = []

    automapping = ""
    # Column types are based on the note categories of the CSAF standard
    # Additional types such as "products" can be selected
    column_types = ["general", "ignore", "description", "details", "faq", "legal_disclaimer", "other", "summary",
                    "products", "publishing_date", "contact_details", "acknowledgment", "title", "solution",
                    "references"]
    header_mapping = json.dumps(column_mapping)
    template_references = json.dumps(template_references)
    return render_template("addtask_post2.html", df=df, column_types=column_types, automapping=automapping,
                           request_form_prev=request.form, header_mapping=header_mapping,
                           template_references=template_references)


@app.route("/addtask3", methods=["POST"])
def addtask3_post():
    # Create mapping from all attributes starting with the prefix "yy_". The prefix itself (first 3 chars) is removed-
    content_mapping = []
    for key in request.form.keys():
        values = request.form.getlist(key)
        for value in values:
            if key.startswith("yy_"):
                content_mapping.append((key[3:], value))

    # This needs to be a list of tuples instead of a dict since the keys can occur multiple times.
    content_mapping_json = json.dumps(content_mapping)

    task = form_to_task(request.form, mapping=request.form.get("header_mapping"),
                        content_mapping=content_mapping_json)
    session_task.add(task)
    session_task.commit()
    flash("Overview Task Added", "success")
    return redirect(url_for("overviewtasks"))


@app.route("/export", methods=["GET"])
def export():
    csv_data = io.StringIO()
    csv_writer = csv.writer(csv_data)
    records = session_task.query(TaskOverview).all()

    # write table headers
    column_names = TaskOverview.__table__.columns.keys()
    csv_writer.writerow(column_names)

    # write line for every record in table
    for record in records:
        csv_writer.writerow([getattr(record, column.name) for column in TaskOverview.__mapper__.columns])

    return Response(csv_data.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment;filename=overviewpage.csv"})


@app.route("/stats", methods=["GET"])
def stats():
    return render_template("stats2.html")


@app.route("/preview", methods=["GET"])
def preview():
    url_params = request.args
    cve = url_params.get("cve")
    provider = url_params.get("provider")
    vendor = url_params.get("vendor")
    date = url_params.get("date")
    if provider:
        advisories = session_csaf.query(Document).where(Document.url.contains(provider)).order_by(
            Document.published.desc()).limit(100).all()
    elif cve:
        vulnerability = session_csaf.query(Vulnerability).where(Vulnerability.identifier == cve).first()
        advisories = vulnerability.documents
    elif vendor:
        vendor_orm = session_csaf.query(Vendor).where(Vendor.name == vendor).first()
        advisories = vendor_orm.documents
    elif date:
        advisories = session_csaf.query(Document).where(and_(Document.published.startswith(date))).limit(100)
    else:
        advisories = session_csaf.query(Document).order_by(Document.published.desc()).limit(100).all()
    advisories = documents_to_dicts(advisories)

    return render_template("preview.html", advisories=advisories)


@app.route("/advisorystats", methods=["GET"])
def advisorystats():
    statement = text(
        "SELECT COUNT(1), substr(document.published,1,10) AS ddate FROM document "
        "GROUP BY substr(document.published,1,10) ORDER BY ddate ASC;")
    max_records = 40
    with engine_csaf.connect() as con:
        rs = con.execute(statement)
        resp = [f"{date},{num}" for num, date in list(rs)[-max_records:]]
        resp = "Date,Value\r\n" + "\r\n".join(resp)
    flask_resp = make_response(resp, 200)
    flask_resp.mimetype = "text/plain"
    return flask_resp
