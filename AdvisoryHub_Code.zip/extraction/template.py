from extraction.mainextraction import Extractor

main = {
    "document": {
        "aggregate_severity": {
            "text": None
        },
        "category": "csaf_security_advisory",
        "csaf_version": "2.0",
        "distribution": {
            "text": "Retrieved via CSA Retrieval Tool; Copyright lies with respective authors/publishers.",
            "tlp": {
                "label": "WHITE",
                "url": "https://www.first.org/tlp/"
            }
        },
        "lang": None,
        "notes": None,
        "publisher": {
            "category": "other",
            "name": None,
            "namespace": None
        },
        "references": None,
        "title": None,
        "tracking": {
            "current_release_date": None,
            "generator": {
                "date": None,
                "engine": {
                    "name": "Security Advisory Retrieval Tool"
                }
            },
            "id": None,
            "initial_release_date": None,
            "revision_history": None,
            "status": "draft",
            "version": None
        }
    },
    "product_tree": None,
    "vulnerabilities": None
}


def populate_template(ex: Extractor, vulnerabilities: [dict]) -> dict:
    document = main["document"]

    url = ex.task.url if ex.task.url else ex.task.domain
    self_ref = {"self": "self", "summary": "HTML URL", "url": url}

    # Populate document
    document["aggregate_severity"]["text"] = ex.severity
    document["lang"] = ex.language
    document["notes"] = ex.notes
    document["publisher"]["name"] = ex.publisher_name
    document["publisher"]["namespace"] = ex.publisher_namespace
    document["references"] = [self_ref] + ex.references
    document["title"] = ex.title
    document["tracking"]["current_release_date"] = ex.timeline[-1]["date"]
    document["tracking"]["generator"]["date"] = ex.extraction_time
    document["tracking"]["id"] = ex.identifier
    document["tracking"]["initial_release_date"] = ex.timeline[0]["date"]
    document["tracking"]["revision_history"] = ex.timeline
    document["tracking"]["version"] = ex.timeline[-1]["number"]

    # Populate product tree
    main["product_tree"] = ex.product_tree

    # Populate vulnerabilities
    main["vulnerabilities"] = vulnerabilities

    return main
