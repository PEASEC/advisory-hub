import json
import os
import re
from urllib.parse import urlparse

from deepdiff import DeepDiff

from extraction.mainextraction import Extractor
from extraction.template import populate_template


class DokumentGenerator:
    def __init__(self, ex: Extractor):
        self.storage_root = "resources/download-details/"
        self.extractor = ex
        self.directory = urlparse(ex.task.domain).netloc
        if not os.path.isdir(self.storage_root + self.directory):
            os.makedirs(self.storage_root + self.directory)  # Create dir if it does exist yet
        # Creating file name in accordance to 5.1 CSAF standard
        self.filename = re.sub(r"[^+\-a-z0-9]+", "_", ex.identifier.lower()) + ".json"
        self.oldfile = self.load_old_file()
        if self.oldfile:
            self.check_for_changes()

    def load_old_file(self) -> {}:
        """Returns an empty dict if no old file can be found."""
        path = f"{self.storage_root}{self.directory}/{self.filename}"
        if os.path.isfile(path):
            with open(path, "r") as file:
                try:
                    return json.load(file)
                except Exception as e:
                    return {}

    def check_for_changes(self):
        old_file = self.oldfile
        new_file = self.generate()
        diff = dict(DeepDiff(old_file, new_file))
        change_locations = []
        if "values_changed" in diff.keys():
            for key in diff["values_changed"].keys():
                if key != "root['document']['tracking']['generator']['date']":
                    change_location = re.findall(r"(?<=\[')\w+(?='\])", key)
                    change_locations.append(change_location)
                    # print(f"Change in {change_location}")
        return change_locations

    def generate_vulnerabilities(self) -> [dict]:
        """Create vulnerability tree and attach score if possible."""
        vulnerabilities = [{"cve": vuln, "title": vuln} for vuln in self.extractor.cve_lst]
        if self.extractor.cvss_score:
            scores = [{"cvss_v3": {"baseScore": self.extractor.cvss_score}}]
            for vulnerability in vulnerabilities:
                vulnerability["scores"] = scores
        return vulnerabilities

    def generate(self) -> {}:
        """Transform an extractor object into a dictionary that can then be converted into a json file."""
        advisory_dict = populate_template(ex=self.extractor, vulnerabilities=self.generate_vulnerabilities())
        return advisory_dict

    def to_disk(self):
        path = f"{self.storage_root}/{self.directory}/{self.filename}"
        with open(path, "w") as file:
            json.dump(self.generate(), file)
            print("Wrote JSON")


if __name__ == '__main__':
    from sqlalchemy.orm import Session
    from sqlalchemy import create_engine
    from datamodel.task import TaskDetail
    from helper.task import get_random_tasks

    engine = create_engine("sqlite:///resources/task.db", echo=False)

    s1 = Session(engine)

    url1 = "https://www.intel.com/content/www/us/en/security-center/advisory/intel-sa-00680.html"
    url2 = "https://linux.oracle.com/errata/ELSA-2024-1615.html"
    url3 = "https://security.snyk.io/vuln/SNYK-GOLANG-GITHUBCOMICEWHALETECHCASAOSUSERSERVICEROUTEV1-6515653"
    url4 = "https://security.gentoo.org/glsa/201310-12"
    url5 = "https://alas.aws.amazon.com/AL2/ALAS-2022-1743.html"
    url6 = "https://www.zerodayinitiative.com/advisories/ZDI-24-354/"
    url7 = "https://cert-portal.siemens.com/productcert/html/ssa-566905.html"
    url8 = "https://access.redhat.com/errata/RHBA-2024:1580"

    tasks = s1.query(TaskDetail).where(
        TaskDetail.domain == "https://psirt.bosch.com/security-advisories/").limit(100)
    # tasks = sample(list(tasks), 1)
    tasks = get_random_tasks(s1, n=5)

    for task in tasks:
        import requests

        if task.url:
            response = requests.get(task.url)
        else:
            response = None

        o = Extractor(task, response, engine)
        d1 = DokumentGenerator(o)
        # print(d1.generate())
        # print(d1.extractor.vendors)
        # print(d1.extractor.products)
        # print(d1.extractor.product_tree)
        # d1.to_disk()
