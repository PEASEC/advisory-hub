import re
import urllib.parse

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from datamodel.cpe import Vendor
from helper.cpe_lookup import lookup_field, generate_n_grams, prepare_for_db_lookup


def extract_vendor_from_url(ex, s1) -> [Vendor]:
    ignorelist = ["snyk", "cve", "mit"]

    if not ex.task.url:
        return []

    url_str = ex.task.url
    try:
        url_str = urllib.parse.urlparse(url_str).hostname
        url_str = url_str.split(".")[-2]
        url_str = url_str.lower()
    except Exception as e:
        return []

    result = s1.query(Vendor).where(Vendor.name == url_str).first()

    if result and result not in ignorelist:
        return [result]
    else:
        return []


def extract_vendor_from_task_vendor_field(ex, s1) -> [Vendor]:
    if not ex.task.vendor:
        return []

    v_str = ex.task.vendor.lower()

    r = lookup_field(s1, v_str, Vendor)

    vendors = []
    for v in r:
        vendors.append(v)
    return vendors


def extract_vendor_from_task_product_field(ex, s1) -> [Vendor]:
    if not ex.task.products:
        return []

    field_str = ex.task.products.lower()
    field_lst = prepare_for_db_lookup(field_str)  # lowercase and split into list of words

    r = []  # result_list
    for v_str in field_lst:
        r += lookup_field(s1, v_str, Vendor)

    vendors = []
    for v in r:
        vendors.append(v)
    vendors = list(set(vendors))
    return vendors


def extract_vendor_from_title(ex, s1) -> [Vendor]:
    if not ex.title:
        return []

    title = re.sub(r"[^0-9a-zA-Z\-_ ]+", "", ex.title.lower())  # Remove all special characters
    title_ngrams = generate_n_grams(title)

    r = []  # result_list
    for v_str in title_ngrams:
        r += lookup_field(s1, v_str, Vendor)

    vendors = []
    for v in r:
        vendors.append(v)
    return vendors


def extract_vendor_from_content(ex, s1) -> [Vendor]:
    content = ex.get_page_content()
    content_ngrams = generate_n_grams(content)
    results = []
    for ngram in content_ngrams:
        results += s1.query(Vendor).where(Vendor.name == ngram).all()
    results_str_lst = [res for res in results]
    return results_str_lst


def extract_vendors(ex) -> (str, str):
    engine = create_engine("sqlite:///resources/cpe.db", echo=False)
    s1 = Session(engine)

    functions = [extract_vendor_from_url, extract_vendor_from_task_vendor_field, extract_vendor_from_task_product_field,
                 extract_vendor_from_title]

    results = []
    for func in functions:
        func_results = func(ex, s1)
        for res in func_results:
            results.append((res.name, func.__name__))
    return results
