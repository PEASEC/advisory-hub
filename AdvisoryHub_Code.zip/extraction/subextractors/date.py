import re
import dateutil.parser
from datetime import datetime

date1 = r"(?<= )\d\d?\.\d\d?\.20\d\d"  # 01.01.2024
date2 = r"(?<= )\d\d? [A-Z][a-z][a-z] 20\d\d"  # 1 Jan 2024
date3 = r"(?<= )[A-Z][a-z]{2,8} \d\d+\w?\w?,? 20\d\d"  # January 10th, 2024
date4 = r"(?<= )\d\d/\d\d/20\d\d"  # 05/09/2023
date5 = r"(?<= )20\d\d\-\d\d\-\d\d"  # 2024-01-01

date_patterns = [date1, date2, date3, date4, date5]
vulnerability_states = ["discovered", "reported", "published", "patched", "updated"]

date_context_words = {
    "published": "published",
    "disclosed": "reported",
    "introduced": "reported",
    "release": "published",
    "reported to vendor": "reported",
    "vendor disclosure": "reported",
    "vendor patch release": "patched",
    "public release": "published",
    "publication date": "published",
    "update": "updated",
    "latest revision": "updated",
    "advisory issued": "published",
    "original release": "published",
    "last revised": "updated",
    "initial vendor contact": "reported"
}


def extract_dates_from_content(ex) -> [(str, datetime)]:
    full_text_no_ws = ex.get_page_content()

    results = []
    for pattern in date_patterns:
        search = list(re.finditer(pattern, full_text_no_ws))
        if search:
            # print(f"Found {len(search)} results with pattern {pattern}")
            for result in search:
                results.append(result)

    dates = []
    output = []

    for res in results:
        date = {"context_left": None, "date": None, "context_right": None}
        date["date"] = dateutil.parser.parse(res.group(0))
        span = res.span()

        context_left_str = full_text_no_ws[span[0] - 30:span[0]].lower()  # 30 chars left of match
        context_right_str = full_text_no_ws[span[1]:span[1] + 30].lower()  # 30 chars right of match

        # print(f"{context_left_str} - [date] {context_right_str}")
        for con in date_context_words.keys():
            if con in context_left_str:
                date["context_left"] = date_context_words[con]
            if con in context_right_str:
                date["context_right"] = date_context_words[con]

        if date["context_left"]:
            output.append((date["context_left"], date["date"]))
        elif date["context_right"]:
            output.append((date["context_right"], date["date"]))
    return output


def extract_dates_from_task(ex) -> [(str, datetime)]:
    task = ex.task

    output = []
    if task.firstseen:
        output.append(("first seen", dateutil.parser.parse(task.firstseen)))
    if task.published:
        output.append(("published", dateutil.parser.parse(task.published)))
    if task.updated:
        output.append(("updated", dateutil.parser.parse(task.updated)))
    return output


def build_timeline(ex):
    try:
        r1 = extract_dates_from_task(ex)
    except Exception as e:
        r1 = []
    try:
        r2 = extract_dates_from_content(ex)
    except Exception as e:
        r2 = []

    timeline_events = ["published", "updated", "first seen"]
    timeline_event = {
        "date": "",
        "number": "",
        "summary": ""
    }

    timeline = {}

    # Add initial publication date
    published_events_dt = []
    for event, dt in r1 + r2:
        if event in ["published", "first seen"]:
            published_events_dt.append(dt.replace(tzinfo=None))  # Must remove tz to compare dt objects later on
    earliest = min(published_events_dt)

    # Add update events
    updated_events_dt = []
    for event, dt in r1 + r2:
        if event in ["updated"]:
            updated_events_dt.append(dt.replace(tzinfo=None))  # Must remove tz to compare dt objects later on
    updated_events_dt = sorted(list(set(updated_events_dt)))  # deduplicate and sort

    # Build timeline
    timeline = []
    timeline.append({
        "date": earliest.isoformat(),
        "number": 1,
        "summary": "Published"
    })
    for num, dt in enumerate(updated_events_dt):
        timeline.append({
            "date": dt.isoformat(),
            "number": num + 1,
            "summary": "Updated"
        })

    return timeline
    # print(r1)
    # print(r2)
    # TODO: Add plausibility checks
    # Update is always >= publishing
    # First seen should be after published (what about time zones)?

    # timeline = {}

    # """
    ## set conf values:
    # conf_r1 = 0.8
    # r1 = [(date_type, date_dt, conf_r1) for date_type, date_dt in r1]
    # conf_r2 = 0.6
    # r2 = [(date_type, date_dt, conf_r2) for date_type, date_dt in r2]

    # results_combined = r1 + r2

    # for status in vulnerability_states:
    #    sublist = [(date_type, date_dt, date_conf) for date_type, date_dt, date_conf in results_combined if
    #               date_type == status]
    #    if sublist:
    #        best_result = max(sublist, key=lambda x: (x[2]))
    #        timeline[status] = best_result
    #
    # dates = timeline
    # """
    # functions = [extract_dates_from_task, extract_dates_from_content]
    # results = []
    # for func in functions:
    #    results = results + [(date_type, date_dt, func.__name__) for date_type, date_dt in func(ex)]
    # return results
