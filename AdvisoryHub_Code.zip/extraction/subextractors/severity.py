import re

severities = {"critical": ["critical"],
              "high": ["high", "important"],
              "medium": ["medium", "moderate"],
              "low": ["low", "not affected"],
              "na": ["None", "nan"]}


def extract_severity_from_task(ex) -> str:
    if not ex.task.severity:
        return "na"

    for sev, examples in severities.items():
        if any([example in ex.task.severity.lower() for example in examples]):
            return sev

    return "na"


def extract_severity_from_content(ex) -> str:
    full_text_no_ws = ex.get_page_content()

    pattern = "severity"
    search = list(re.finditer(pattern, full_text_no_ws))
    if search:
        results = [result for result in search]  # list of match objects

        for res in results:
            date = {"context_left": None, "context_right": None}
            span = res.span()

            context_left_str = full_text_no_ws[span[0] - 30:span[0]].lower()  # 30 chars left of match
            context_right_str = full_text_no_ws[span[1]:span[1] + 30].lower()  # 30 chars right of match

            for sev, examples in severities.items():
                if any([example in context_left_str for example in examples]) or any(
                        [example in context_right_str for example in examples]):
                    return sev

    return "na"


def generate_severity_from_score(ex) -> str:
    if not ex.cvss_score:
        print(ex.cvss_score)
        return "na"

    try:
        score = float(ex.cvss_score)
    except ValueError as e:
        return "na"

    if score >= 8:
        return "critical"
    if score >= 6:
        return "high"
    if score >= 4:
        return "medium"
    else:
        return "low"


def extract_severity(ex) -> str:
    functions = [extract_severity_from_task, extract_severity_from_content, generate_severity_from_score]

    results = []
    for func in functions:
        func_results = func(ex)
        results.append((func_results, func.__name__))
    for severity, subextractorname in results:
        if severity != "na":
            return severity
    return "na"
