import re
from lxml import etree


def extract_notes_from_content(ex) -> [dict]:
    if not ex.tree:
        return []
    full_text = ""
    for text in ex.tree.getroot().itertext():
        full_text = full_text + text + " "
    full_text = re.sub(r"\n +", "\n", full_text)
    full_text = re.sub(r"\n{2,}", "\n\n", full_text)

    output_dict = {
        "category": "other",
        "text": full_text,
        "title": "Text extracted from detail page."}
    return [output_dict]


def extract_notes_from_task(ex) -> [dict]:
    notes = []
    if ex.task.summary:
        summary_text = remove_html_tags(ex.task.summary)
        notes.append({
            "category": "summary",
            "text": summary_text,
            "title": "Summary (from task)"})

    if ex.task.content:
        content_text = remove_html_tags(ex.task.content)
        notes.append({
            "category": "other",
            "text": content_text,
            "title": "Content (from task)"})
    return notes


def remove_html_tags(text) -> str:
    # Heuristic to detect html code in field
    if "<p>" in text or "<br" in text:
        try:
            tree = etree.fromstring(text)
            full_text = ""
            for text in tree.getroot().itertext():
                full_text = full_text + text + " "
            full_text = re.sub(r"\n +", "\n", full_text)
            return re.sub(r"\n{2,}", "\n\n", full_text)
        except Exception as e:
            pass
    return text


def extract_notes(ex) -> [dict]:
    notes1 = extract_notes_from_task(ex)
    notes2 = extract_notes_from_content(ex)
    return notes1 + notes2
