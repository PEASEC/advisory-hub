import dateutil.parser
import datefinder

sample1 = "29 Mar 2024"
sample2 = "2024-03-28"
sample3 = "November 14, 2023"
sample4 = "Publication Date  2022-05-02"
sample5 = "03/12/2024"
sample6 = "2024-03-27T16:00:00.000+0000"
sample7 = "2023-08-24 00:59:55"

samples = [sample1, sample2, sample3, sample4, sample5, sample6, sample7]

for sample in samples:
    try:
        date_ps = dateutil.parser.parse(sample)
        print(date_ps)
    except dateutil.parser._parser.ParserError:
        matches = datefinder.find_dates(sample)
        if matches:
            for m in matches:
                print(f"Datefinder: {m}")
        else:
            print(f"Couldn't parse date: {sample}")
