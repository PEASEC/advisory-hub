from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from datamodel.cpe import Vendor, Product
from helper.cpe_lookup import lookup_field, prepare_for_db_lookup


def extract_products_from_task_product_field(ex, s1) -> [Product]:
    if not ex.task.products:
        return []

    # TODO: Split product filed that looks like this: ['product1', 'product2']

    field_str = ex.task.products.lower()
    field_lst = prepare_for_db_lookup(field_str)  # lowercase and split into list of words

    r = []  # result_list
    for v_str in field_lst:
        r += lookup_field(s1, v_str, Product)

    vendors = []
    for v in r:
        vendors.append(v)
    vendors = list(set(vendors))
    return vendors


def check_if_in_products_field(ex, candidate):
    if not ex.task.products:
        return False
    if candidate in ex.task.products:
        return True
    else:
        return False


def check_if_in_content(ex, candidate):
    content = " ".join(ex.content_text.split())
    content_underscore = content.replace(" ", "_")
    if candidate in content_underscore:
        return True
    else:
        return False


def check_if_in_title(ex, candidate):
    if not ex.title:
        return False
    title_underscore = ex.title.replace(" ", "_").lower()
    if candidate in title_underscore:
        return True
    else:
        return False


def extract_products(ex):
    vendors = [v[0] for v in ex.vendors]

    engine = create_engine("sqlite:///resources/cpe.db", echo=False)
    s1 = Session(engine)

    vendors = [s1.query(Vendor).where(Vendor.name == v).first() for v in vendors]

    if vendors:
        candidateproducts = list(set([p.name for v in vendors for p in v.products]))  # deduplicatee list of p names
    else:
        candidateproducts = []

    # print(f"Candidateproducts: {[can.name for can in candidateproducts]}")

    results = [candidate for candidate in candidateproducts if check_if_in_title(ex, candidate)]
    results += [candidate for candidate in candidateproducts if check_if_in_products_field(ex, candidate)]

    if not results:
        # Search more aggressively
        results += [candidate for candidate in candidateproducts if check_if_in_content(ex, candidate)]

    if not results:
        # Search even more aggressively (without limitation to products of already found vendors)
        products = extract_products_from_task_product_field(ex, s1)
        for prod in products:
            ex.vendors.append((prod.vendor.name, "extract_products"))
        results = [prod.name for prod in products]
    return results


def create_product_tree(ex) -> {}:
    tree = {"branches": []}

    engine = create_engine("sqlite:///resources/cpe.db", echo=False)
    s1 = Session(engine)

    vendors = list(set([v for v, em in ex.vendors]))

    for v in vendors:
        vendor_db_result = s1.query(Vendor).where(Vendor.name == v).first()
        if vendor_db_result:
            vendor_branch = {"category": "vendor", "name": vendor_db_result.name, "branches": []}
            for product in vendor_db_result.products:
                if product.name in ex.products:
                    product_branch = {"category": "product_name", "name": product.name}
                    vendor_branch["branches"].append(product_branch)
            tree["branches"].append(vendor_branch)
    return tree
