import urllib.parse


def extract_publisher_name(ex) -> str:
    if ex.task.url:
        extraction_field = ex.task.url
    elif ex.task.domain:
        extraction_field = ex.task.domain
    else:
        return "No publisher"

    try:
        urllib.parse.urlparse(extraction_field).hostname.split(".")[-2]
    except Exception as e:
        return "No publisher"
