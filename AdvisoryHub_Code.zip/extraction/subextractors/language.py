from langdetect import detect


def extract_language(ex):
    text = ex.get_page_content()
    try:
        language = detect(text)
    except Exception as e:
        # TODO: language detection library sometimes has problems with multithreading, search for alternatives
        language = "en"
    return language
