import re


def extract_cpes_from_sting(text: str) -> [str]:
    cpe_find_regex = (r"([AHOaho\*\-](:(((\?*|\*?)([a-zA-Z0-9\-\._]|(\\[\\\*\?!\"#\$%&'\(\)\+,/:;<=>@"
                      r"\[\]\^`\{\|\}~]))+(\?*|\*?))|[\*\-])){5,10})")
    cpe_matches = re.findall(cpe_find_regex, text)
    return cpe_matches


def extract_cpes_from_content(ex) -> [str]:
    if not ex.content_text:
        return []
    return extract_cpes_from_sting(ex.content_text)


def extract_cpes_from_task(ex) -> [str]:
    cpes = []
    for k, v in ex.task.__dict__.items():
        if isinstance(v, str):
            cpes_in_v = extract_cpes_from_sting(v)
            cpes += cpes_in_v
    return cpes


def extract_cpes(ex) -> [str]:
    cpes_in_task = extract_cpes_from_task(ex)
    cpes_in_content = extract_cpes_from_content(ex)
    cpes = list(set(cpes_in_task + cpes_in_content))
    if cpes:
        print(f"ALERT: CPEs found {cpes}")
    return cpes
