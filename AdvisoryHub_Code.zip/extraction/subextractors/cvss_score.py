import re

from cvss import CVSS3, CVSS2

regex_cwe = r"CWE-[1-9]\\d{0,5}"
score_pattern = r"\d\.\d"
prefix_pattern = r"CVSS|cvss|Base Score|BASE SCORE|base score"


def extract_cvss_based_on_cvss_prefix(text: str) -> [str]:
    CONTEXT_SIZE = 45

    m1 = re.finditer(prefix_pattern, text)
    searches = [m1]
    results = []
    scores = []

    for search in searches:
        for result in search:
            results.append(result)

    for res in results:
        # Search in the vicinity of cvss match
        span = res.span()
        context = text[span[0] - CONTEXT_SIZE:span[1] + CONTEXT_SIZE]
        score = re.search(score_pattern, context)
        if score:
            scores.append(score.group(0))

    # Filtering out cvss version numbers
    # Not perfect, but acceptable since it is only low numbers indicating low severity
    scores = [score for score in scores if score not in ["0.0", "2.0", "3.0", "3.1", "4.0"]]

    return scores


def calculate_score_cvss_from_vector(ex) -> [str]:
    scores = []

    if ex.cvss_vector_lst:
        for vector in ex.cvss_vector_lst:
            version = 3 if "S:" in vector[0] else 2
            try:
                if version == 3:
                    vector_test = "CVSS:3.0/" + vector[0]
                    c = CVSS3(vector_test)
                    scores.append(str(c.base_score))
                elif version == 2:
                    c = CVSS2(vector[0])
                    scores.append(str(c.base_score))

            except Exception as e:
                pass

    return scores


def extract_cvss_score_from_content(ex) -> [str]:
    if not ex.content_text:
        return []

    full_text = ex.content_text
    return extract_cvss_based_on_cvss_prefix(full_text)


def extract_cvss_score_from_task_score_field(ex) -> [str]:
    if ex.task.score:
        match = re.search(score_pattern, ex.task.score)
        if match:
            return [match.group()]
    return []


def extract_cvss_score_from_task(ex) -> [str]:
    task_as_dict_str = str(ex.task.__dict__)
    return extract_cvss_based_on_cvss_prefix(task_as_dict_str)


def extract_cvss_score(ex) -> str:
    functions = [extract_cvss_score_from_task_score_field, calculate_score_cvss_from_vector,
                 extract_cvss_score_from_task, extract_cvss_score_from_content]
    results = []
    for func in functions:
        results = results + [(score, func.__name__) for score in func(ex)]
    if results:
        result = str(max([float(res[0]) for res in results]))
    else:
        result = ""
    return result
