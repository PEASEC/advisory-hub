import re

regex_cvss_vector = r"(\w+:\w+\/){7,}\w+:\w+"
regex_cvss_vector_31 = r"CVSS:3\.1(\/\w+:\w+){8,}"
regex_cvss_vector_4 = r"CVSS:4\.0(\/\w+:\w+){8,}"


def extract_cvss_vector_from_content(ex):
    full_text_no_ws = ex.get_page_content()
    m1 = re.finditer(regex_cvss_vector, full_text_no_ws)
    cvss_vector_lst = []
    if m1:
        for m in m1:
            cvss_vector_lst.append(m.group(0))
    return cvss_vector_lst


def extract_cvss_vector_from_task(ex) -> [str]:
    vectors = []
    for k, v in ex.task.__dict__.items():
        if isinstance(v, str):
            found_vectors = re.findall(regex_cvss_vector, v)
            vectors += found_vectors
    return vectors


def extract_cvss_vector(ex):
    functions = [extract_cvss_vector_from_content, extract_cvss_vector_from_task]
    results = []
    for func in functions:
        results = results + [score for score in func(ex)]  # Option return tuple (score, func.__name__)
    return list(set(results))
