import json
import urllib.parse

from helper.element import dictify_element


def extract_references(ex) -> [{}]:
    if not ex.tree:
        return []
    links = set(ex.tree.xpath('//a'))
    links_dict = [dictify_element(link) for link in links]
    try:
        template_references = set(json.loads(ex.overviewtask.ignorereferences))
    except json.decoder.JSONDecodeError:
        template_references = []

    references = []
    seen_urls = []
    for link in links_dict:
        summary = link.get("a-text", "")
        url = link.get("a.href", "")
        path = urllib.parse.urlparse(url=url).path

        # Filter out bad references
        if url in seen_urls:
            continue
        if not url.startswith("http://") and not url.startswith("https://"):
            continue
        if url in template_references:
            continue
        if not url:
            continue
        if path in ["", "/"]:
            continue

        references.append({"category": "external", "summary": summary, "url": url})
        seen_urls.append(url)

    return references
