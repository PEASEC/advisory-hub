import os
import urllib.parse


def url_to_identifier(url: str) -> str:
    # Build identifier from url
    file_extensions = ["html"]

    if url.endswith("/"):
        url = url[:-1]
    url_parsed = urllib.parse.urlparse(url)
    file_name = os.path.basename(url_parsed.path)

    for extension in file_extensions:  # remove file extensions
        if file_name.endswith(f".{extension}"):
            file_name = file_name.replace(f".{extension}", "")

    if url_parsed.query:
        query_identifier_keys = ["name", "cve", "id", "version"]
        query = {k: v[0] for k, v in urllib.parse.parse_qs(url_parsed.query).items()}  # {arg1: val1, arg2: val2}
        for key in query_identifier_keys:
            if key in query.keys():
                return query.get(key)

    return file_name


def extract_identifier(ex):
    if ex.task.identifier:
        if ex.task.identifier.endswith(".json"):
            return ex.task.identifier[:-5]
        return ex.task.identifier
    else:
        return url_to_identifier(ex.task.url)


if __name__ == '__main__':
    url1 = "https://wid.cert-bund.de/portal/wid/securityadvisory?name=WID-SEC-2024-0655"
    url2 = "https://www.cve.org/CVERecord?id=CVE-2023-43622"
    url3 = "https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/cisco-sa-iosxr-ssh-privesc-eWDMKew3?vs_f=Cisco%20Security%20Advisory&vs_cat=Security%20Intelligence&vs_type=RSS&vs_p=Cisco%20IOS%20XR%20Software%20SSH%20Privilege%20Escalation%20Vulnerability&vs_k=1"
    url4 = "https://my.f5.com/manage/s/article/K000139083?utm_source=f5support&utm_medium=RSS"
    url5 = "https://www.postgresql.org/support/security/CVE-2020-14349/"
    url6 = "https://access.redhat.com/errata/RHSA-2024:1576"
    url7 = "https://cert-portal.siemens.com/productcert/html/ssa-256353.html"
    print(url_to_identifier(url7))
