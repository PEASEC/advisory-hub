def extract_title(ex) -> str:
    if ex.task.title:
        return ex.task.title
    if not ex.task.title and ex.tree:
        t = ex.tree.find(".//title").text
        if t:
            return t
    if ex.identifier:
        return ex.identifier
    return ""
