import re


def extract_cves_from_content(ex) -> [str]:
    if not ex.content_text:
        return []
    full_text = ex.content_text.lower()
    results = re.findall(r"cve-[0-9]{4}-[0-9]{4,}", full_text)
    results = [cve_str.upper() for cve_str in results]  # Make cves uppercase again
    return list(set(results))


def extract_cves_from_task(ex) -> [str]:
    cves = []
    for k, v in ex.task.__dict__.items():
        if isinstance(v, str):
            cves_in_v = re.findall(r"CVE-[0-9]{4}-[0-9]{4,}", v)
            cves += cves_in_v
    return cves


def extract_cves_with_meta(ex):
    in_meta = set(extract_cves_from_task(ex))
    in_content = set(extract_cves_from_content(ex))
    out = []

    functions = [extract_cves_from_content, extract_cves_from_task]
    results = []
    for func in functions:
        results = results + [(cve, func.__name__) for cve in func(ex)]
    return results


def extract_cves(ex) -> [str]:
    cves_content = extract_cves_from_content(ex)
    cves_title = extract_cves_from_task(ex)
    return list(set(cves_content + cves_title))
