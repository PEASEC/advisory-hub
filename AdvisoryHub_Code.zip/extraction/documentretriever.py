import requests

from datamodel.task import TaskDetail


class Retriever:
    def __init__(self, task: TaskDetail):
        self.TIMEOUT = 30
        self.task = task
        self.request_headers = None
        self.response = None
        self.etag = None
        self.last_modified = None
        self.make_request()

    def retrieve(self):
        status_code = self.make_request()
        if status_code == 200:
            print("New content available.")

    def make_request(self) -> int:
        if not self.request_headers:
            self.request_headers = {}
        self.request_headers["If-Modified-Since"] = "Fri, 29 Mar 2022 09:28:21 GMT"
        self.response = requests.get(self.task.url, timeout=self.TIMEOUT, headers=self.request_headers)
        self.etag = self.response.headers.get("etag")
        self.last_modified = self.response.headers.get("date")
        return self.response.status_code
