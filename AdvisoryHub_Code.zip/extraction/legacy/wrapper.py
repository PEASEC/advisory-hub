import numpy as np
import pandas as pd
from helper.treehelper import clean_tree, tree_to_records
import json


class WrapperGenerator:
    def __init__(self, trees: []):
        # Take 5 trees
        self.trees = trees

        # Dynamic is True if there is at least one attribute that is not common
        self.dynamic_headers = {
            "h1": {"dynamic": False, "common_attributes": []},
            "h2": {"dynamic": False, "common_attributes": []},
            "h3": {"dynamic": False, "common_attributes": []}
        }
        self.df = pd.DataFrame()
        self.tables = []  # list of lists containing tuples: (location, table)

    def preprocess_trees(self):
        # Remove irrelevant elements and tables from trees
        for tree in self.trees:
            clean_tree(tree)

    def get_template_refs(self):
        """Extract references that are part of the template and not part of the individual advisory."""
        references = [tree.xpath('//a/@href') for tree in self.trees]  # Create list of lists containing references
        common_references = list(set.intersection(*map(set, references)))
        return common_references

    def populate_df(self):
        # Read all elements in all trees and put them into a df
        # Columns: document no, h1, h2, h3, content

        records = []
        for num, tree in enumerate(self.trees):
            new_records = [rec for rec in tree_to_records(tree)]
            for rec in new_records:
                rec["DocId"] = num
            records += new_records
        df = pd.DataFrame(records)
        self.df = df

    def isolate_dynamic_headers(self):
        """
        Determine which headers are static across different pages and which ones change.
        Dynamic headers are replaced by a "*" in the data frame
        # TODO: Consider adding alternative symbol for * if there is more than one dynamic header
        """

        for htag in self.dynamic_headers.keys():  # iterate over h1, h2, h3
            # Survey h1 -> most likely distinct heading
            grouped = self.df.groupby(htag)['DocId'].unique()  # This is a series consisting of index: array(int)

            # Create dict and build mask from it
            # E.g. {..."'ELSA-2024-1141'": 1, "'ELSA-2024-1147'": 1, 'None': 7}
            d = {k: len(v) for k, v in grouped.to_dict().items()}
            values_to_move = [k for k, v in d.items() if v < len(self.trees) * 0.5]
            non_unique_values = set(self.df[htag].tolist()) - set(values_to_move)
            if len(values_to_move) > 0:
                self.dynamic_headers[htag]["dynamic"] = True
                if non_unique_values:
                    self.dynamic_headers[htag]["common_attributes"] = list(non_unique_values)
            print(f"Non-unique values: {non_unique_values}")
            mask = self.df[htag].isin(values_to_move)

            # self.df.loc[mask, 'header1'] = self.df.loc[mask, 'h1']

            self.df.loc[mask, htag] = "*"
        # print(self.df)
        # print(f"Dynamic headers: {self.dynamic_headers}")

    def analyze_structure(self):
        """Return all attributes that can be extracted from a page."""
        attributes = set()

        # Attributes from page
        for index, row in self.df.iterrows():
            attributes.add(json.dumps([row["h1"], row["h2"], row["h3"]]))

        # Attributes from tables
        for table_list in self.tables:
            for location, table in table_list:
                columns = table.columns.tolist()
                for col in columns:
                    attributes.add(col)

        print(attributes)

    def dump_df(self):
        self.df.to_csv("test123.csv", index=False)

    def transpose(self):
        return transpose(self.df)


def create_header_type_mapping(rec_lst):
    """Create a mapping of headers to the contents across multiple samples of a detail page."""
    # Create h1-h2-h3-doc_id : content mapping
    out_dict = {}
    for rec in rec_lst:
        doc_id = rec['DocId']
        key = (rec["h1"], rec["h2"], rec["h3"], doc_id)
        if key in out_dict.keys():
            if out_dict[key] is not None:
                out_dict[key] = out_dict[key] + "\n" + rec["content"]
            else:
                print(f"Key is none: {key}")
        else:
            out_dict[key] = rec["content"]

    # Flatten dict / Create h1-h2-h3 : content_lst mapping
    out_dict2 = {}
    for k, v in out_dict.items():
        k0, k1, k2, k3 = k  # k3 is the doc_id
        key_new = (k0, k1, k2)
        if key_new in out_dict2.keys():
            if out_dict2[key_new] is not None:
                out_dict2[key_new].append(v)
            else:
                # print(f"Key is none: {key_new}")
                pass
        else:
            out_dict2[key_new] = [v]

    return out_dict2


def transpose(df: pd.DataFrame) -> pd.DataFrame:
    """
    Take a dataframe that is structured like this:
    h1-h2-h3-content1-DocId1
    h2-h2-h3-content2-DocId2
    And transform it into this:
    h1-h2-h3-content1-content2
    """
    grouped = df.groupby("DocId")
    dfs = []
    for group_name, group_df in grouped:
        group_df.drop("DocId", axis=1, inplace=True)
        group_df.set_index(["h1", "h2", "h3"], inplace=True)  # Setting index for merging
        dfs.append(group_df)

    index_is_unique = all([df.index.is_unique for df in dfs])
    if not index_is_unique:
        # Special case where the index (that consists of h1,h2,h3) is not unique
        # df_t = dfs[0].merge(dfs[1], how="outer")
        for df in dfs:
            df.reset_index(inplace=True)

        for df in dfs[1:]:  # Drop h1,h2,h3 columns in every df except the first one
            df.drop("h1", axis=1, inplace=True)
            df.drop("h2", axis=1, inplace=True)
            df.drop("h3", axis=1, inplace=True)

        df_t = pd.concat(dfs, join="outer", axis=1).fillna(np.nan)
    else:
        # Regular case where index is unique
        df_t = pd.concat(dfs, join="outer", axis=1).fillna(np.nan)
        df_t.reset_index(inplace=True)
        # All examples are presented

    return df_t


if __name__ == '__main__':
    from extraction.legacy.extraction_funcs import load_pages
    from sqlalchemy.orm import Session
    from sqlalchemy import create_engine
    from datamodel.task import TaskDetail

    engine = create_engine("sqlite:///resources/task.db", echo=False)

    s1 = Session(engine)

    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    domain = "https://www.talosintelligence.com/vulnerability_reports/"
    example_tds = s1.query(TaskDetail).where(TaskDetail.domain == domain).limit(8).all()
    example_urls = [td.url for td in example_tds]
    trees = load_pages(url_list=example_urls)  # list of trees

    wg = WrapperGenerator(trees)
    test1 = wg.get_template_refs()
    print(test1)
    # wg.preprocess_trees()
    # wg.populate_df()
    # wg.isolate_dynamic_headers()
    # print(wg.df)
    # rec_lst = wg.df.to_dict('records')

    # mapping = create_header_type_mapping(rec_lst)
    # for k, v in mapping.items():
    #    print(f"Key: {k} - Values: {v}")

    # print(transpose(wg.df))

# wg.dump_df()
# for tab in wg.tables[0]:
#     print(tab)
# wg.analyze_structure()
