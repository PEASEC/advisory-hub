import requests
from lxml import etree
import pandas as pd
import collections
import re
import wrapper_functions

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)


class Scraper:
    def __init__(self):
        pass

    def build_wrapper(self, urls: list, wrapper_func=None):
        """
        1. Iterate over all urls and retrieve them.
        2. Parse each retrieved site into a tree and let the wrapper function dissemble it into key value-pairs.
        3. Construct a data frame from the key-value pairs.
        # TODO: Handle tables separately
        """
        if wrapper_func is None:
            wrapper_func = self.wrapper_func_header2
        ignore_tags = ["footer", "script", "style", "table", "comment"]
        lst = []
        dfs = []
        for num, url in enumerate(urls):
            response = requests.get(url)
            html_parser = etree.HTMLParser()
            root = etree.fromstring(response.text, parser=html_parser)
            tree = etree.ElementTree(root, parser=html_parser)
            row = {}
            row, dfs = wrapper_func(root, tree, ignore_tags)
            lst.append(row)
        df = pd.DataFrame.from_records(lst)
        df.dropna(how='all', axis=1, inplace=True)
        print(df.shape)
        print(df)
        print("Additional tables:")
        for df in dfs:
            print(df)

    def create_selector_list(self, urls: list, wrapper_func=None) -> (list, list):
        """
        1. Iterate over all urls and retrieve them.
        2. Parse each retrieved site into a tree and let the wrapper function dissemble it into key value-pairs.
        3. Construct a data frame from the key-value pairs.
        # TODO: Handle tables separately
        """
        if wrapper_func is None:
            wrapper_func = wrapper_functions.wrapper_func_header5

        ignore_tags = ["footer", "script", "style", "table"]
        lst = []
        dfs = []

        # Iterate over urls and apply wrapper function
        for num, url in enumerate(urls):
            response = requests.get(url)
            html_parser = etree.HTMLParser()
            root = etree.fromstring(response.text, parser=html_parser)
            tree = etree.ElementTree(root, parser=html_parser)
            row = {}
            row, dfs = wrapper_func(root, tree, ignore_tags)
            print(type(row))
            lst.append(row)
        df = pd.DataFrame.from_records(lst)
        print(df)
        df.dropna(how='all', axis=1, inplace=True)  # I don't remember why I did this
        content_selectors = []

        # Remove content selectors/attributes that occur only on one detail page
        for col_name in df.columns:
            if df[col_name].count() > 1:
                content_selectors.append(col_name)
                df.drop(col_name, axis=1, inplace=True)
        # print(df)
        list_of_dicts = df.to_dict('records')

        # the following line inverts every dict in the list of dicts, ignore nan values
        swapped = [dict((v, k) for k, v in lst.items() if isinstance(v, str)) for lst in list_of_dicts]
        df2 = pd.DataFrame(swapped)
        location_selectors = list(df2.keys())
        return content_selectors, location_selectors

    def build_wrapper3(self, urls: list, wrapper_func=None, content_selectors=None, path_selectors=None):
        """
        Call h-tag analyzer
        """
        if wrapper_func is None:
            wrapper_func = self.wrapper_func_header5
        ignore_tags = ["footer", "script", "style", "table", ""]
        lst = []
        dfs = []
        for num, url in enumerate(urls):
            response = requests.get(url)
            html_parser = etree.HTMLParser(remove_comments=True)
            root = etree.fromstring(response.text, parser=html_parser)
            tree = etree.ElementTree(root, parser=html_parser)
            row = {}
            row, dfs = wrapper_func(root, tree, ignore_tags, content_selectors=content_selectors,
                                    path_selectors=path_selectors)
            lst.append(row)
        print(lst)
        df = pd.DataFrame.from_records(lst)
        return df

    def html_to_markdown(self, root):
        # TODO: Text is not extracted from every element
        output = ""
        tree = etree.ElementTree(root)
        for element in tree.iter():
            text = ""
            if element.text:
                text = str(element.text).strip()
                if element.tag in ["h1", "h2", "h3", "h4", "h5", "h6"]:
                    output = output + "\r\n" + element.text + "\r\n"
                elif element.tag in ["p", "span", "div"]:
                    output = output + " " + text
                elif element.tag in ["a", "b"]:
                    output = output + "" + text
        print(output)

    def print_trees(self, A: str, B: str):
        root_A = etree.fromstring(A)
        root_B = etree.fromstring(B)

        tree_A = etree.ElementTree(root_A)
        tree_B = etree.ElementTree(root_B)
        for e_A, e_B in zip(root_A.iter(), root_B.iter()):
            try:
                print(
                    f"PathA: {tree_A.getpath(e_A)} - "
                    f"ClassA: {e_A.attrib.get("class")} - "
                    f"IDA: {e_A.attrib.get("id")} - "
                    f"ContentA: {str(e_A.text).strip()} - "
                )
                # print(
                #    f"PathB: {tree_B.getpath(e_B)} - "
                #    f"ClassB: {e_B.attrib.get("class")} - "
                #    f"IDB: {e_B.attrib.get("id")} - "
                #    f"ContentB: {e_B.text} - "
                # )
            except Exception as ex:
                print(ex)

    def pretty_print(self, root, tree):
        # Source: https://python-forum.io/thread-6204.html

        nice_tree = collections.OrderedDict()

        for tag in root.iter():
            path = re.sub(r'\[[0-9]+\]', '', tree.getpath(tag))
            if path not in nice_tree:
                nice_tree[path] = []
            if len(tag.keys()) > 0:
                nice_tree[path].extend(attrib for attrib in tag.keys() if attrib not in nice_tree[path])

        for path, attribs in nice_tree.items():
            indent = int(path.count('/') - 1)
            print(
                f"{'    ' * indent}"
                f"{indent}:"
                f"{path.split('/')[-1]} "
                f"[{', '.join(attribs) if len(attribs) > 0 else '-'}]")

    def pretty_print2(self, root, tree):
        # Source: https://python-forum.io/thread-6204.html
        import collections
        import re

        nice_tree = collections.OrderedDict()

        for tag in root.iter():
            # Iterate over all elements in tree (_Element type)
            path = re.sub(r'\[[0-9]+\]', '', tree.getpath(tag))  # handle element counter such as: [2]
            indent = int(path.count('/') - 1)
            print(
                f"{'    ' * indent}"
                f"{indent}:"
                f"{path.split('/')[-1]} "
                f"[{', '.join(tag.keys()) if len(tag.keys()) > 0 else '-'}]")


def tree_notation_to_css(path: str) -> str:
    """Transforms xpath into css tag selector string"""
    path = re.sub(r"\[", ":nth-child(", path)
    path = re.sub(r"\]", ")", path)
    path = re.sub(r"/", ">", path)
    return path


if __name__ == '__main__':
    from extraction.legacy.sample import *

    s = Scraper()
    content_selectors, location_selectors = s.create_selector_list(lst_2, wrapper_functions.wrapper_func_header5)
    print(f"Content Selectors: {content_selectors}")
    print(f"Location_selectors: {location_selectors}")
    df = s.build_wrapper3(lst_2, wrapper_functions.wrapper_func_header6, content_selectors=content_selectors,
                          path_selectors=location_selectors)

    df.to_csv("../resources/test_extraction.csv", index=False)
    # s.html_to_markdown(lst_1)
    # s. match_trees2(lst_1[0], lst_4[1])

    # import spacy

    # test = (' August 23rd, 2023 7-Zip 7Z File Parsing Integer Underflow Remote Code Execution Vulnerability ZDI-23-1165 ZDI-CAN-18588 <table style="max-width: 100%;"> CVE ID <a href="https://www.cve.org/CVERecord?id=CVE-2023-31102">CVE-2023-31102 CVSS SCORE 7.8, <a href="http://nvd.nist.gov/cvss.cfm?calculator&amp;version=3.0&amp;vector=AV:L/AC:L/PR:N/UI:R/S:U/C:H/I:H/A:H">AV:L/AC:L/PR:N/UI:R/S:U/C:H/I:H/A:H AFFECTED VENDORS 7-Zip AFFECTED PRODUCTS 7-Zip VULNERABILITY DETAILS This vulnerability allows remote attackers to execute arbitrary code on affected installations of 7-Zip. User interaction is required to exploit this vulnerability in that the target must visit a malicious page or open a malicious file. The specific flaw exists within the parsing of 7Z files. The issue results from the lack of proper validation of user-supplied data, which can result in an integer underflow before writing to memory. An attacker can leverage this vulnerability to execute code in the context of the current process. ADDITIONAL DETAILS 7-Zip has issued an update to correct this vulnerability. More details can be found at: <a href="https://sourceforge.net/p/sevenzip/discussion/45797/thread/713c8a8269/">https://sourceforge.net/p/sevenzip/discussion/45797/thread/713c8a8269/ DISCLOSURE TIMELINE 2022-11-21 - Vulnerability reported to vendor 2023-08-23 - Coordinated public release of advisory CREDIT goodbyeselene <a href="/advisories/" class="btn mediumButton back-btn">BACK TO ADVISORIES ')
    # nlp = spacy.load("en_core_web_sm")
    # doc = nlp(test)
    # for ent in doc.ents:
    #    print(ent, ent.label_)
    print(tree_notation_to_css('/html/body/div/div/div/main/div'))
