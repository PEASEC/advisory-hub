from lxml.etree import ElementTree
import requests
from lxml import etree


def load_pages(url_list: list) -> [ElementTree]:
    """Take a list of urls, download them into memory and return a list of parsed ElementTree objects."""
    trees = []
    for num, url in enumerate(url_list):
        response = requests.get(url)
        html_parser = etree.HTMLParser(remove_comments=True)
        root = etree.fromstring(response.text, parser=html_parser)
        trees.append(etree.ElementTree(root, parser=html_parser))
    return trees


def strip_dict(d: dict) -> dict:
    """Remove whitespace from dict values."""
    d2 = {}
    for key, value in d.items():
        if isinstance(value, str):
            d2[key] = value.strip()
        elif isinstance(value, dict):
            d2[key] = strip_dict(value)
    return d2
