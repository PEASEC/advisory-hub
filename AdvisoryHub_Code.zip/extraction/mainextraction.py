import re
from datetime import datetime

import pandas as pd
import requests
from bs4 import BeautifulSoup
from lxml import etree
from lxml.etree import _ElementTree
from sqlalchemy.orm import Session

from datamodel.task import TaskDetail, TaskOverview
from extraction.subextractors import *
from helper.task import get_random_tasks
from helper.treehelper import clean_tree, tree_to_records


class Extractor:
    # Set proper id
    # Extract CVEs
    # Extract Products
    # Tablify content

    def __init__(self, task: TaskDetail, response: requests.Response | None, engine):
        self.task = task
        self.session = Session(engine)
        self.overviewtask = self.session.query(TaskOverview).where(TaskOverview.url == TaskDetail.domain).first()
        self.response = response
        self.tree: _ElementTree | None = None
        self.tables = None
        self.content_table = None  # df containing content

        if self.response:
            self.load_tree()

        self.identifier = extract_identifier(self)
        self.title = extract_title(self)  # Must be extracted before tree is cleaned

        if self.tree:
            self.clean_tree()
            self.generate_content_table()
            self.content_text = self.tree2text()
        else:
            self.content_text = ""

        self.cve_lst = extract_cves(self)
        self.cpe_lst = extract_cpes(self)
        self.language = extract_language(self)
        self.references = extract_references(self)
        self.timeline = build_timeline(self)
        self.cvss_vector_lst = extract_cvss_vector(self)
        self.cvss_score = extract_cvss_score(self)
        self.vendors = extract_vendors(self)
        self.products = extract_products(self)
        self.product_tree = create_product_tree(self)
        self.severity = extract_severity(self)
        self.notes = extract_notes(self)

        self.publisher_namespace = self.task.domain
        self.publisher_name = extract_publisher_name(self)

        self.extraction_time = str(datetime.now())
        self.session.close()

    def load_tree(self):
        html_parser = etree.HTMLParser(remove_comments=True)
        root = etree.fromstring(self.response.text, parser=html_parser)
        tree: _ElementTree = etree.ElementTree(root, parser=html_parser)
        self.tree = tree

    def clean_tree(self):
        clean_tree(self.tree)

    def extract(self):
        # self.extract_tables()
        self.generate_content_table()

    def get_page_content(self) -> str:
        if not self.tree:
            return ""
        full_text = ""
        for text in self.tree.getroot().itertext():
            # text = element.text if element.text else " "
            full_text = full_text + text + " "
        full_text_no_ws = " ".join(full_text.split())  # Remove double whitespace
        return full_text_no_ws

    def tree2text(self):
        html = etree.tostring(self.tree, encoding="utf-8", method="html")
        soup = BeautifulSoup(html, features="lxml")
        text = soup.get_text()
        text = re.sub(r'(\r?\n)+', '\r\n', text)
        return text

    # def extract_tables(self):
    #     self.tables = extract_tables(self.tree)

    def generate_content_table(self):
        content_table_records = tree_to_records(self.tree)
        self.content_table = pd.DataFrame.from_records(content_table_records)

    def content_table_to_list(self):
        records = self.content_table.df.to_dict('records')


if __name__ == '__main__':
    from sqlalchemy import create_engine
    from random import randint
    from timeit import default_timer

    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    engine = create_engine("sqlite:///resources/task.db", echo=False)

    s1 = Session(engine)

    provider_url1 = "https://www.dlink.com/de/de/support/support-news"
    provider_url2 = "https://www.oracle.com/security-alerts/"
    provider_url3 = "https://sec.cloudapps.cisco.com/security/center/publicationListing.x"

    # Get random task of a given provider
    task = s1.query(TaskDetail).where(TaskDetail.domain == provider_url3).offset(randint(0, 20)).first()

    # Get a random task of any provider
    # task = get_random_tasks(s1, 5)[0]

    # Make request
    if task.url:
        response = requests.get(task.url)
    else:
        response = None

    # Extract and print
    start = default_timer()
    o = Extractor(task, response, engine)
    end = default_timer()
    print(f"Retrieval duration was: {end - start} seconds.")
    print(f"URL: {o.task.url}")
    print(f"Identifier: {o.identifier}")
    print(f"Title: {o.title}")
    print(f"CVEs: {o.cve_lst}")
    print(f"CPEs: {o.cpe_lst}")
    print(f"CVE Vector List: {o.cvss_vector_lst}")
    print(f"CVE Score List: {o.cvss_score}")
    print(f"Language: {o.language}")
    # print(o.content_table)
    # print(f"References: {o.references}")
    print(f"Timeline: {o.timeline}")
    print(f"Vendors: {o.vendors}")
    print(f"Products: {o.products}")
    print(f"Severity: {o.severity}")
    # print(o.tree2text())
